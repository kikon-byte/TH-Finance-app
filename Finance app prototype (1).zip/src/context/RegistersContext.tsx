import { createContext, useContext, useState, type ReactNode } from 'react'

/* ── Project entry (shared with DayBook) ────────────────────── */
export type ProjectEntry = {
  id: string
  slno: number
  date: string
  projectName: string
  receipt: number | null
  payment: number | null
  source: 'project'
}

type RegistersCtx = {
  projectEntries: ProjectEntry[]
  addProjectEntry: (e: Omit<ProjectEntry, 'id' | 'slno' | 'source'>) => void
}

const Ctx = createContext<RegistersCtx | null>(null)

const seed: ProjectEntry[] = [
  { id: 'p1', slno: 1, date: '06/04/2024', projectName: 'Construction of Pigsty',       receipt: null,   payment: 40800, source: 'project' },
  { id: 'p2', slno: 2, date: '13/04/2024', projectName: 'Construction of Poultry Shed', receipt: null,   payment: 30000, source: 'project' },
  { id: 'p3', slno: 3, date: '23/04/2024', projectName: 'Purchase of Piglets (10 nos)', receipt: null,   payment: 70000, source: 'project' },
  { id: 'p4', slno: 4, date: '19/06/2024', projectName: 'Sale of Broiler (Batch 1)',    receipt: 28000,  payment: null,  source: 'project' },
  { id: 'p5', slno: 5, date: '19/07/2024', projectName: 'Sale of Broiler (Batch 2)',    receipt: 16800,  payment: null,  source: 'project' },
  { id: 'p6', slno: 6, date: '03/10/2025', projectName: 'Sale of Pig (2 nos × 90kg)',  receipt: 54000,  payment: null,  source: 'project' },
  { id: 'p7', slno: 7, date: '08/05/2024', projectName: 'Broiler Chicks Batch 1',      receipt: null,   payment: 8000,  source: 'project' },
  { id: 'p8', slno: 8, date: '08/06/2024', projectName: 'Broiler Chicks Batch 2',      receipt: null,   payment: 3200,  source: 'project' },
  { id: 'p9', slno: 9, date: '10/08/2024', projectName: 'Broiler Chicks Batch 3',      receipt: null,   payment: 8000,  source: 'project' },
]

export function RegistersProvider({ children }: { children: ReactNode }) {
  const [projectEntries, setProjectEntries] = useState<ProjectEntry[]>(seed)

  const addProjectEntry = (e: Omit<ProjectEntry, 'id' | 'slno' | 'source'>) => {
    setProjectEntries(prev => [
      ...prev,
      { ...e, id: `p${Date.now()}`, slno: prev.length + 1, source: 'project' },
    ])
  }

  return <Ctx.Provider value={{ projectEntries, addProjectEntry }}>{children}</Ctx.Provider>
}

export function useRegisters() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useRegisters must be used inside RegistersProvider')
  return ctx
}
