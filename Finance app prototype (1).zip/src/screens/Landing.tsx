import { useNavigate } from 'react-router'
import logoSrc from '../imports/1_cover_page.jpg'

const MODULES = [
  {
    to: '/dashboard',
    icon: '⬡',
    label: 'Dashboard',
    desc: 'Financial overview — KPIs, recovery progress, recent transactions at a glance.',
    color: '#1a8cff',
    stat: '₹2.32L',
    statLabel: 'Total Portfolio',
  },
  {
    to: '/members',
    icon: '👥',
    label: 'Membership Register',
    desc: 'Member records, share holdings, loan eligibility and NSCU membership status.',
    color: '#60a5fa',
    stat: '18',
    statLabel: 'Members',
  },
  {
    to: '/daybook',
    icon: '📒',
    label: 'Day Book',
    desc: 'Daily financial register — all receipts and payments, auto-synced with Project Register.',
    color: '#00d4aa',
    stat: '113+',
    statLabel: 'Entries',
  },
  {
    to: '/loans',
    icon: '₹',
    label: 'Loan Register & Ledger',
    desc: 'Disbursement, repayment, and monthly repayment schedule — all three in one place.',
    color: '#f0b429',
    stat: '₹1.50L',
    statLabel: 'Disbursed',
  },
  {
    to: '/shares',
    icon: '📋',
    label: 'Share Ledger',
    desc: 'Share subscription register for all society members with balance tracking.',
    color: '#a78bfa',
    stat: '₹72,000',
    statLabel: 'Share Capital',
  },
  {
    to: '/projects',
    icon: '🏗',
    label: 'Project Register',
    desc: 'Project-wise receipts & payments that auto-sync into the Day Book in real time.',
    color: '#fb923c',
    stat: '9',
    statLabel: 'Projects',
  },
  {
    to: '/stock',
    icon: '📦',
    label: 'Stock & Investment',
    desc: 'Stock ledger and project investment register with P&L tracking.',
    color: '#34d399',
    stat: '₹10,150',
    statLabel: 'Stock Value',
  },
  {
    to: '/assets',
    icon: '🏛',
    label: 'Asset Register',
    desc: 'Fixed assets accounting ledger — utensils, vehicles, machinery with WDV depreciation.',
    color: '#f472b6',
    stat: '26',
    statLabel: 'Assets',
  },
]

const FEATURES = [
  { icon: '⬇', label: 'CSV / Spreadsheet Export', desc: 'Download any register as a CSV file — opens directly in Google Sheets or Excel.' },
  { icon: '🔍', label: 'Search & Filter', desc: 'Instantly search and filter records across every register.' },
  { icon: '＋', label: 'Live Data Entry', desc: 'Add new entries inline without leaving the page.' },
  { icon: '📐', label: 'WDV Depreciation', desc: 'Automatic written-down-value depreciation on all fixed assets.' },
  { icon: '₹', label: 'INR Formatted', desc: 'All amounts display in Indian Rupee notation with lakhs / crores formatting.' },
  { icon: '🔒', label: 'Audit Ready', desc: 'Structured registers aligned with co-operative society audit requirements.' },
]

export default function Landing() {
  const nav = useNavigate()

  return (
    <div style={{ color: '#e6edf3', fontFamily: 'var(--font-sans)' }}>

      {/* ── Hero ──────────────────────────────────────────────── */}
      <section style={{
        minHeight: '100vh',
        background: 'radial-gradient(ellipse 80% 60% at 50% -10%, #1a8cff18 0%, transparent 70%), #0d1117',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        padding: '80px 24px 60px',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Background grid */}
        <div style={{
          position: 'absolute', inset: 0, zIndex: 0,
          backgroundImage: 'linear-gradient(#30363d22 1px,transparent 1px),linear-gradient(90deg,#30363d22 1px,transparent 1px)',
          backgroundSize: '48px 48px',
          maskImage: 'radial-gradient(ellipse 80% 60% at 50% 0%, black 0%, transparent 80%)',
        }} />

        {/* Nav bar inside hero */}
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 200,
          background: '#0d111799', backdropFilter: 'blur(12px)',
          borderBottom: '1px solid #30363d44',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 32px', height: 56,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <img src={logoSrc} alt="Tribal Harvest Marketing Co-ops"
              style={{ width: 40, height: 40, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }} />
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, color: '#e6edf3' }}>Tribal Harvest</div>
              <div style={{ fontSize: 10, color: '#8b949e', lineHeight: 1 }}>Marketing Co-ops · Finance System</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => nav('/dashboard')} className="btn-ghost" style={{ fontSize: 12 }}>Dashboard</button>
            <button onClick={() => nav('/members')} className="btn-primary" style={{ fontSize: 12 }}>Open Registers →</button>
          </div>
        </div>

        {/* Hero content */}
        <div style={{ position: 'relative', zIndex: 1, maxWidth: 720 }}>
          {/* Hero logo */}
          <div style={{ marginBottom: 28, display: 'flex', justifyContent: 'center' }}>
            <div style={{ position: 'relative', display: 'inline-block' }}>
              <div style={{
                position: 'absolute', inset: -6,
                borderRadius: '50%',
                background: 'conic-gradient(from 0deg, #1a8cff44, #00d4aa44, #f0b42944, #1a8cff44)',
                filter: 'blur(8px)',
                zIndex: 0,
              }} />
              <img src={logoSrc} alt="Tribal Harvest Marketing Co-ops"
                style={{
                  width: 120, height: 120,
                  borderRadius: '50%',
                  objectFit: 'cover',
                  border: '3px solid #30363d',
                  position: 'relative', zIndex: 1,
                  boxShadow: '0 0 40px #1a8cff33, 0 8px 32px #00000088',
                }} />
            </div>
          </div>

          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: '#1a8cff18', border: '1px solid #1a8cff44',
            borderRadius: 20, padding: '5px 14px',
            fontSize: 12, fontWeight: 600, color: '#1a8cff',
            fontFamily: 'var(--font-display)', marginBottom: 28,
          }}>
            <span style={{ width: 6, height: 6, background: '#3fb950', borderRadius: '50%', display: 'inline-block' }} />
            Live · FY 2024–25 · Tribal Harvest Marketing Co-ops
          </div>

          <h1 style={{
            fontFamily: 'var(--font-display)', fontWeight: 800,
            fontSize: 'clamp(32px, 6vw, 64px)',
            lineHeight: 1.1, color: '#e6edf3',
            margin: '0 0 20px',
            letterSpacing: '-1.5px',
          }}>
            Tribal Harvest<br />
            <span style={{ background: 'linear-gradient(90deg,#1a8cff,#00d4aa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Finance Made Simple
            </span>
          </h1>

          <p style={{ fontSize: 16, color: '#8b949e', lineHeight: 1.7, margin: '0 0 40px', maxWidth: 560, marginLeft: 'auto', marginRight: 'auto' }}>
            A complete digital ledger system for Tribal Harvest Marketing Co-ops — day books, loan registers,
            share ledgers, asset tracking, and stock management. Export any register to CSV or Google Sheets in one click.
          </p>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button onClick={() => nav('/dashboard')} className="btn-primary" style={{ padding: '12px 28px', fontSize: 14, gap: 8 }}>
              View Dashboard →
            </button>
            <button onClick={() => {
              document.getElementById('modules')?.scrollIntoView({ behavior: 'smooth' })
            }} className="btn-ghost" style={{ padding: '12px 28px', fontSize: 14 }}>
              Explore Registers
            </button>
          </div>

          {/* Mini stat strip */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 32, marginTop: 56, flexWrap: 'wrap' }}>
            {[
              { v: '₹1.50L', l: 'Loans Disbursed' },
              { v: '73%', l: 'Recovery Rate' },
              { v: '₹72K', l: 'Share Capital' },
              { v: '26', l: 'Fixed Assets' },
              { v: '7', l: 'Registers' },
            ].map(s => (
              <div key={s.l} style={{ textAlign: 'center' }}>
                <div className="amount" style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: '#e6edf3' }}>{s.v}</div>
                <div style={{ fontSize: 11, color: '#8b949e', marginTop: 2 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Modules grid ─────────────────────────────────────── */}
      <section id="modules" style={{ padding: '80px 32px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 52 }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'clamp(24px,4vw,40px)', color: '#e6edf3', margin: '0 0 12px', letterSpacing: '-0.5px' }}>
            8 Dedicated Registers
          </h2>
          <p style={{ color: '#8b949e', fontSize: 15 }}>Each module is a dedicated page with search, filters, and CSV export.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(310px, 1fr))', gap: 20 }}>
          {MODULES.map(m => (
            <button
              key={m.to}
              onClick={() => nav(m.to)}
              style={{
                background: '#161b22',
                border: '1px solid #30363d',
                borderRadius: 16,
                padding: '26px 28px',
                textAlign: 'left',
                cursor: 'pointer',
                transition: 'border-color 0.2s, transform 0.15s, box-shadow 0.2s',
                display: 'flex', flexDirection: 'column', gap: 14,
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLButtonElement).style.borderColor = m.color + '88'
                ;(e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-3px)'
                ;(e.currentTarget as HTMLButtonElement).style.boxShadow = `0 12px 40px ${m.color}18`
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLButtonElement).style.borderColor = '#30363d'
                ;(e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)'
                ;(e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div style={{
                  width: 44, height: 44,
                  background: m.color + '22',
                  border: `1px solid ${m.color}44`,
                  borderRadius: 12,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 20,
                }}>{m.icon}</div>
                <div style={{ textAlign: 'right' }}>
                  <div className="amount" style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: m.color }}>{m.stat}</div>
                  <div style={{ fontSize: 10, color: '#8b949e' }}>{m.statLabel}</div>
                </div>
              </div>

              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: '#e6edf3', marginBottom: 6 }}>{m.label}</div>
                <div style={{ fontSize: 13, color: '#8b949e', lineHeight: 1.6 }}>{m.desc}</div>
              </div>

              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 5,
                color: m.color, fontSize: 12, fontWeight: 600, fontFamily: 'var(--font-display)',
              }}>
                Open Register <span>→</span>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* ── Features ─────────────────────────────────────────── */}
      <section style={{ padding: '60px 32px 80px', background: '#161b22', borderTop: '1px solid #30363d', borderBottom: '1px solid #30363d' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'clamp(22px,3.5vw,36px)', color: '#e6edf3', margin: '0 0 44px', textAlign: 'center', letterSpacing: '-0.5px' }}>
            Built for Co-operative Society Audits
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 20 }}>
            {FEATURES.map(f => (
              <div key={f.label} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                <div style={{
                  width: 36, height: 36, flexShrink: 0,
                  background: '#1a8cff22', border: '1px solid #1a8cff44',
                  borderRadius: 10,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 15, color: '#1a8cff',
                }}>{f.icon}</div>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: '#e6edf3', marginBottom: 4 }}>{f.label}</div>
                  <div style={{ fontSize: 13, color: '#8b949e', lineHeight: 1.6 }}>{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA footer ───────────────────────────────────────── */}
      <section style={{ padding: '72px 32px', textAlign: 'center' }}>
        <div style={{ maxWidth: 560, margin: '0 auto' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'clamp(22px,3.5vw,36px)', color: '#e6edf3', margin: '0 0 16px', letterSpacing: '-0.5px' }}>
            Ready to manage your registers?
          </h2>
          <p style={{ color: '#8b949e', fontSize: 15, marginBottom: 32 }}>
            Jump directly into the Day Book, Loan Register, or any module below.
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 10, flexWrap: 'wrap' }}>
            {MODULES.map(m => (
              <button key={m.to} onClick={() => nav(m.to)} style={{
                background: m.color + '18', color: m.color,
                border: `1px solid ${m.color}44`,
                borderRadius: 8, padding: '7px 16px',
                fontSize: 12, fontWeight: 600, fontFamily: 'var(--font-display)',
                cursor: 'pointer', transition: 'all 0.15s',
              }}
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = m.color + '33' }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = m.color + '18' }}
              >
                {m.label}
              </button>
            ))}
          </div>
          <p style={{ marginTop: 40, fontSize: 12, color: '#30363d' }}>
            XX IMPCS Ltd. · Integrated Multi-Purpose Co-operative Society · FY 2024–25
          </p>
        </div>
      </section>
    </div>
  )
}
