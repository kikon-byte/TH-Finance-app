import { useState } from 'react'
import { useRegisters } from '../context/RegistersContext'
import { downloadCSV } from '../utils/downloadCSV'

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

type Filter = 'all' | 'receipt' | 'payment'

export default function ProjectRegister() {
  const { projectEntries, addProjectEntry } = useRegisters()
  const [filter, setFilter] = useState<Filter>('all')
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [draft, setDraft] = useState({ date: '', projectName: '', receipt: '', payment: '' })

  const filtered = projectEntries.filter(e => {
    if (filter === 'receipt' && !e.receipt) return false
    if (filter === 'payment' && !e.payment) return false
    if (search && !e.projectName.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const totalReceipt = filtered.reduce((s, e) => s + (e.receipt ?? 0), 0)
  const totalPayment = filtered.reduce((s, e) => s + (e.payment ?? 0), 0)

  const handleSave = () => {
    if (!draft.date || !draft.projectName) return
    addProjectEntry({
      date: draft.date,
      projectName: draft.projectName,
      receipt: draft.receipt ? +draft.receipt : null,
      payment: draft.payment ? +draft.payment : null,
    })
    setDraft({ date: '', projectName: '', receipt: '', payment: '' })
    setShowAdd(false)
  }

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 22 }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, color: '#e6edf3', margin: 0 }}>
            Project Register
          </h1>
          <p style={{ color: '#8b949e', fontSize: 13, margin: '4px 0 0' }}>
            Project-wise receipts &amp; payments · auto-synced to Day Book
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-ghost" style={{ fontSize: 12 }} onClick={() =>
            downloadCSV('impcs-project-register.csv',
              ['Sl.No', 'Date', 'Name of the Project', 'Receipt (₹)', 'Payment (₹)'],
              [filtered.map(e => [e.slno, e.date, e.projectName, e.receipt ?? '', e.payment ?? ''])])
          }>⬇ CSV</button>
          <button className="btn-primary" onClick={() => setShowAdd(v => !v)}>+ New Entry</button>
        </div>
      </div>

      {/* KPI strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14 }}>
        {[
          { label: 'Total Project Receipts', value: totalReceipt, color: '#3fb950' },
          { label: 'Total Project Payments', value: totalPayment, color: '#f85149' },
          { label: 'Net (Receipt − Payment)', value: totalReceipt - totalPayment, color: totalReceipt - totalPayment >= 0 ? '#00d4aa' : '#f85149' },
        ].map(c => (
          <div key={c.label} style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 10, padding: '16px 20px' }}>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>{c.label}</div>
            <div className="amount" style={{ fontSize: 22, fontWeight: 700, color: c.color }}>{fmt(c.value)}</div>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
        <input placeholder="Search project..." value={search} onChange={e => setSearch(e.target.value)} style={{ width: 220 }} />
        <div style={{ display: 'flex', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, padding: 3, gap: 1 }}>
          {(['all', 'receipt', 'payment'] as Filter[]).map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{
              background: filter === f ? '#1a8cff' : 'transparent',
              color: filter === f ? 'white' : '#8b949e',
              borderTop: 'none', borderLeft: 'none', borderRight: 'none', borderBottom: 'none',
              borderRadius: 5, padding: '5px 14px', fontSize: 12, fontWeight: 600,
              fontFamily: 'var(--font-display)', cursor: 'pointer', textTransform: 'capitalize',
            }}>{f}</button>
          ))}
        </div>
      </div>

      {/* Add form */}
      {showAdd && (
        <div style={{ background: '#161b22', border: '1px solid #1a8cff44', borderRadius: 12, padding: 20, display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>Date *</div>
            <input type="date" value={draft.date} onChange={e => setDraft(d => ({ ...d, date: e.target.value }))} style={{ width: 150 }} />
          </div>
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>Name of the Project *</div>
            <input placeholder="e.g. Construction of Pigsty" value={draft.projectName} onChange={e => setDraft(d => ({ ...d, projectName: e.target.value }))} style={{ width: '100%' }} />
          </div>
          <div>
            <div style={{ fontSize: 11, color: '#3fb950', marginBottom: 4 }}>Receipt (₹)</div>
            <input type="number" placeholder="0" value={draft.receipt} onChange={e => setDraft(d => ({ ...d, receipt: e.target.value }))} style={{ width: 130 }} />
          </div>
          <div>
            <div style={{ fontSize: 11, color: '#f85149', marginBottom: 4 }}>Payment (₹)</div>
            <input type="number" placeholder="0" value={draft.payment} onChange={e => setDraft(d => ({ ...d, payment: e.target.value }))} style={{ width: 130 }} />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-primary" onClick={handleSave}>Save</button>
            <button className="btn-ghost" onClick={() => setShowAdd(false)}>Cancel</button>
          </div>
        </div>
      )}

      {/* Sync notice */}
      <div style={{ background: '#00d4aa0d', border: '1px solid #00d4aa33', borderRadius: 10, padding: '11px 18px', display: 'flex', gap: 10, alignItems: 'center' }}>
        <span style={{ color: '#00d4aa', fontSize: 16 }}>⟳</span>
        <span style={{ fontSize: 12, color: '#8b949e' }}>
          <strong style={{ color: '#00d4aa' }}>Auto-sync active —</strong> every entry saved here is immediately visible in the Day Book register with a <em>Project</em> source badge.
        </span>
      </div>

      {/* Table */}
      <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden' }}>
        <div style={{ padding: '13px 20px', borderBottom: '1px solid #30363d', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: '#e6edf3' }}>
            Project Register — {filtered.length} entries
          </span>
          <span style={{ fontSize: 12, color: '#8b949e' }}>XX IMPCS Ltd.</span>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th style={{ width: 60 }}>Sl.No</th>
                <th>Date</th>
                <th>Name of the Project</th>
                <th style={{ textAlign: 'right' }}>Receipt (₹)</th>
                <th style={{ textAlign: 'right' }}>Payment (₹)</th>
                <th>Synced to Day Book</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(e => (
                <tr key={e.id}>
                  <td className="amount" style={{ color: '#8b949e' }}>{e.slno}</td>
                  <td className="amount" style={{ fontSize: 12, color: '#8b949e' }}>{e.date}</td>
                  <td style={{ fontWeight: 600 }}>{e.projectName}</td>
                  <td className="amount" style={{ textAlign: 'right', color: '#3fb950', fontWeight: e.receipt ? 600 : 400 }}>
                    {e.receipt ? fmt(e.receipt) : <span style={{ color: '#30363d' }}>—</span>}
                  </td>
                  <td className="amount" style={{ textAlign: 'right', color: '#f85149', fontWeight: e.payment ? 600 : 400 }}>
                    {e.payment ? fmt(e.payment) : <span style={{ color: '#30363d' }}>—</span>}
                  </td>
                  <td>
                    <span style={{ background: '#00d4aa18', color: '#00d4aa', border: '1px solid #00d4aa44', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-display)' }}>
                      ✓ Synced
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3} style={{ color: '#8b949e' }}>Total</td>
                <td className="amount" style={{ textAlign: 'right', color: '#3fb950' }}>{fmt(totalReceipt)}</td>
                <td className="amount" style={{ textAlign: 'right', color: '#f85149' }}>{fmt(totalPayment)}</td>
                <td />
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  )
}
