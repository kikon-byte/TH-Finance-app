import { useState } from 'react'
import { downloadCSV } from '../utils/downloadCSV'

const fmt = (n: number | null) =>
  n == null ? '—' : new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

type Member = {
  acNo: string; name: string; address: string; phone: string;
  disburseDate: string; amountDisbursed: number; interestRate: string; repayDate: string;
  payments: { month: string; amount: number | null }[];
}

const months = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar']

const membersData: Member[] = [
  {
    acNo: 'SB/001', name: 'John', address: 'XX Village', phone: '98XXXXXX01',
    disburseDate: '05/04/2023', amountDisbursed: 10000, interestRate: '10% p.a.', repayDate: '05/04/2024',
    payments: months.map((m, i) => ({ month: m, amount: i < 10 ? null : 10000 })),
  },
  {
    acNo: 'SB/002', name: 'Member 2', address: 'XX Village', phone: '98XXXXXX02',
    disburseDate: '05/04/2023', amountDisbursed: 10000, interestRate: '10% p.a.', repayDate: '05/04/2024',
    payments: months.map((m, i) => ({ month: m, amount: i < 10 ? null : 10000 })),
  },
  {
    acNo: 'SB/003', name: 'Member 3', address: 'XX Village', phone: '98XXXXXX03',
    disburseDate: '05/04/2023', amountDisbursed: 10000, interestRate: '10% p.a.', repayDate: '05/04/2024',
    payments: months.map((m, i) => ({ month: m, amount: i < 10 ? null : 10000 })),
  },
  {
    acNo: 'SB/011', name: 'Member 11', address: 'XX Village', phone: '98XXXXXX11',
    disburseDate: '15/09/2024', amountDisbursed: 10000, interestRate: '10% p.a.', repayDate: '15/09/2026',
    payments: months.map(() => ({ month: '', amount: null })),
  },
  {
    acNo: 'SB/012', name: 'Member 12', address: 'XX Village', phone: '98XXXXXX12',
    disburseDate: '15/09/2024', amountDisbursed: 10000, interestRate: '10% p.a.', repayDate: '15/09/2026',
    payments: months.map(() => ({ month: '', amount: null })),
  },
  {
    acNo: 'SB/013', name: 'Member 13', address: 'XX Village', phone: '98XXXXXX13',
    disburseDate: '15/09/2024', amountDisbursed: 10000, interestRate: '10% p.a.', repayDate: '15/09/2026',
    payments: months.map(() => ({ month: '', amount: null })),
  },
]

export default function LoanLedger() {
  const [selected, setSelected] = useState<Member>(membersData[0])

  const totalPaid = selected.payments.reduce((s, p) => s + (p.amount || 0), 0)
  const outstanding = selected.amountDisbursed - totalPaid

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, color: '#e6edf3', margin: 0 }}>
          Loan Ledger Register
        </h1>
        <p style={{ color: '#8b949e', fontSize: 13, margin: '4px 0 0' }}>
          Monthly repayment schedule · Option 1 (Monthly payments)
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 20 }}>
        {/* Member list */}
        <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden', alignSelf: 'start' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid #30363d', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, color: '#8b949e' }}>
            Members ({membersData.length})
          </div>
          {membersData.map(m => (
            <button key={m.acNo} onClick={() => setSelected(m)} style={{
              display: 'block', width: '100%', textAlign: 'left',
              background: selected.acNo === m.acNo ? 'linear-gradient(135deg, #1a8cff22, #00d4aa11)' : 'transparent',
              borderTop: 'none',
              borderRight: 'none',
              borderLeft: selected.acNo === m.acNo ? '3px solid #1a8cff' : '3px solid transparent',
              borderBottom: '1px solid #21262d',
              padding: '12px 16px', cursor: 'pointer', transition: 'all 0.15s',
            }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, color: selected.acNo === m.acNo ? '#1a8cff' : '#e6edf3' }}>{m.name}</div>
              <div style={{ fontSize: 11, color: '#8b949e', marginTop: 2 }}>{m.acNo} · {m.disburseDate}</div>
              <div style={{ marginTop: 4 }}>
                <span style={{
                  fontSize: 10, fontWeight: 700, fontFamily: 'var(--font-display)',
                  padding: '2px 6px', borderRadius: 3,
                  ...(m.payments.some(p => p.amount) ? { background: '#3fb95022', color: '#3fb950', border: '1px solid #3fb95044' } : { background: '#f0b42922', color: '#f0b429', border: '1px solid #f0b42944' })
                }}>
                  {m.payments.some(p => p.amount) ? 'Repaid' : 'Pending'}
                </span>
              </div>
            </button>
          ))}
        </div>

        {/* Detail view */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Member info */}
          <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, padding: '18px 22px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 16 }}>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, color: '#e6edf3' }}>{selected.name}</div>
                <div style={{ fontSize: 12, color: '#8b949e', marginTop: 2 }}>{selected.address} · {selected.phone}</div>
              </div>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                {[
                  { label: 'A/C No.', value: selected.acNo },
                  { label: 'Disbursed', value: selected.disburseDate },
                  { label: 'Repay By', value: selected.repayDate },
                  { label: 'Interest', value: selected.interestRate },
                ].map(f => (
                  <div key={f.label} style={{ background: '#1c2330', border: '1px solid #30363d', borderRadius: 8, padding: '8px 14px' }}>
                    <div style={{ fontSize: 10, color: '#8b949e' }}>{f.label}</div>
                    <div className="amount" style={{ fontSize: 13, fontWeight: 600, color: '#e6edf3', marginTop: 1 }}>{f.value}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Progress bar */}
            <div style={{ marginTop: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 6 }}>
                <span style={{ color: '#8b949e' }}>Repayment Progress</span>
                <span className="amount" style={{ color: '#00d4aa', fontWeight: 600 }}>
                  {fmt(totalPaid)} / {fmt(selected.amountDisbursed)}
                </span>
              </div>
              <div style={{ height: 8, background: '#1c2330', borderRadius: 4, overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  width: `${Math.min(100, (totalPaid / selected.amountDisbursed) * 100)}%`,
                  background: 'linear-gradient(90deg, #1a8cff, #00d4aa)',
                  borderRadius: 4, transition: 'width 0.4s',
                }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginTop: 4 }}>
                <span style={{ color: '#3fb950' }}>Paid: {fmt(totalPaid)}</span>
                <span style={{ color: outstanding > 0 ? '#f0b429' : '#3fb950' }}>Outstanding: {fmt(outstanding)}</span>
              </div>
            </div>
          </div>

          {/* Monthly schedule table */}
          <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ padding: '12px 20px', borderBottom: '1px solid #30363d', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, color: '#8b949e', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span>Monthly Payment Schedule</span>
              <button className="btn-ghost" style={{ fontSize: 11 }} onClick={() =>
                downloadCSV(
                  `impcs-loan-ledger-${selected.name.replace(/\s/g,'-')}.csv`,
                  ['Member','A/C No','Disbursed','Amount','Interest Rate','Repay Date',...months.map(m=>`Pay-${m}`),'Total Paid','Outstanding'],
                  [[[ selected.name, selected.acNo, selected.disburseDate, selected.amountDisbursed, selected.interestRate, selected.repayDate, ...selected.payments.map(p=>p.amount ?? ''), totalPaid, outstanding ]]],
                )
              }>⬇ CSV</button>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    {months.map(m => <th key={m} style={{ textAlign: 'right', minWidth: 80 }}>Pay Amount<br />{m}</th>)}
                    <th style={{ textAlign: 'right' }}>Total Paid</th>
                    <th style={{ textAlign: 'right' }}>O/S</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    {selected.payments.map((p, i) => (
                      <td key={i} className="amount" style={{
                        textAlign: 'right',
                        color: p.amount ? '#3fb950' : '#30363d',
                        fontWeight: p.amount ? 600 : 400,
                      }}>
                        {p.amount ? fmt(p.amount) : '—'}
                      </td>
                    ))}
                    <td className="amount" style={{ textAlign: 'right', color: '#00d4aa', fontWeight: 700 }}>{fmt(totalPaid)}</td>
                    <td className="amount" style={{ textAlign: 'right', color: outstanding > 0 ? '#f0b429' : '#3fb950', fontWeight: 700 }}>
                      {fmt(outstanding)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
