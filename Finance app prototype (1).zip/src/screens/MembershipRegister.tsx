import { useState } from 'react'
import { downloadCSV } from '../utils/downloadCSV'

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

/* ── Donut chart ─────────────────────────────────────────────── */
type Slice = { label: string; value: number; color: string }

function DonutChart({ data, size = 148, title, subtitle }: { data: Slice[]; size?: number; title: string; subtitle?: string }) {
  const [hovered, setHovered] = useState<number | null>(null)
  const total = data.reduce((s, d) => s + d.value, 0)
  const cx = size / 2, cy = size / 2
  const R = size * 0.40, r = size * 0.26, gap = 0.018

  let cursor = -Math.PI / 2
  const slices = data.map((d, i) => {
    const sweep = total ? (d.value / total) * (2 * Math.PI) - gap : 0
    const sa = cursor + gap / 2, ea = sa + sweep
    const cos = (a: number) => Math.cos(a), sin = (a: number) => Math.sin(a)
    const large = sweep > Math.PI ? 1 : 0
    const path = [
      `M ${cx + R * cos(sa)} ${cy + R * sin(sa)}`,
      `A ${R} ${R} 0 ${large} 1 ${cx + R * cos(ea)} ${cy + R * sin(ea)}`,
      `L ${cx + r * cos(ea)} ${cy + r * sin(ea)}`,
      `A ${r} ${r} 0 ${large} 0 ${cx + r * cos(sa)} ${cy + r * sin(sa)}`,
      'Z',
    ].join(' ')
    const mid = sa + sweep / 2
    cursor += sweep + gap
    return { ...d, path, mid, i }
  })

  const active = hovered !== null ? slices[hovered] : null

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: '#e6edf3' }}>{title}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ overflow: 'visible' }}>
            {slices.map((s) => (
              <path key={s.i} d={s.path}
                fill={s.color}
                opacity={hovered === null || hovered === s.i ? 1 : 0.35}
                style={{ transition: 'opacity 0.15s, transform 0.15s', transformOrigin: `${cx}px ${cy}px`,
                  transform: hovered === s.i ? `scale(1.06)` : 'scale(1)', cursor: 'pointer' }}
                onMouseEnter={() => setHovered(s.i)}
                onMouseLeave={() => setHovered(null)}
              >
                <title>{s.label}: {s.value} ({total ? ((s.value / total) * 100).toFixed(1) : 0}%)</title>
              </path>
            ))}
            {/* Centre */}
            {active ? (
              <>
                <text x={cx} y={cy - 6} textAnchor="middle" fill={active.color} fontSize={16} fontWeight={800} fontFamily="var(--font-display)">{active.value}</text>
                <text x={cx} y={cy + 9} textAnchor="middle" fill="#8b949e" fontSize={9} fontFamily="var(--font-display)">{active.label.toUpperCase()}</text>
              </>
            ) : (
              <>
                <text x={cx} y={cy - 6} textAnchor="middle" fill="#e6edf3" fontSize={18} fontWeight={800} fontFamily="var(--font-display)">{total}</text>
                <text x={cx} y={cy + 9} textAnchor="middle" fill="#8b949e" fontSize={9} fontFamily="var(--font-display)">{subtitle?.toUpperCase() || 'TOTAL'}</text>
              </>
            )}
          </svg>
        </div>
        {/* Legend */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {slices.map((s) => (
            <div key={s.i} style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', opacity: hovered === null || hovered === s.i ? 1 : 0.4, transition: 'opacity 0.15s' }}
              onMouseEnter={() => setHovered(s.i)} onMouseLeave={() => setHovered(null)}>
              <div style={{ width: 10, height: 10, borderRadius: 2, background: s.color, flexShrink: 0 }} />
              <span style={{ fontSize: 12, color: '#8b949e', fontFamily: 'var(--font-display)' }}>{s.label}</span>
              <span className="amount" style={{ fontSize: 12, fontWeight: 700, color: '#e6edf3', marginLeft: 'auto' }}>{s.value}</span>
              <span style={{ fontSize: 11, color: s.color, fontWeight: 600, minWidth: 38, textAlign: 'right' }}>
                {total ? ((s.value / total) * 100).toFixed(0) : 0}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ── Horizontal bar chart ────────────────────────────────────── */
type Bar = { label: string; value: number; color: string; sub?: string }

function HBarChart({ data, title, maxOverride }: { data: Bar[]; title: string; maxOverride?: number }) {
  const [hovered, setHovered] = useState<number | null>(null)
  const max = maxOverride ?? Math.max(...data.map(d => d.value), 1)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: '#e6edf3' }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {data.map((d, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 3 }}
            onMouseEnter={() => setHovered(i)} onMouseLeave={() => setHovered(null)}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontSize: 12, color: hovered === i ? '#e6edf3' : '#8b949e', fontFamily: 'var(--font-display)', fontWeight: 600, transition: 'color 0.15s' }}>
                {d.label}{d.sub ? <span style={{ fontSize: 10, color: '#30363d', marginLeft: 4 }}>{d.sub}</span> : null}
              </span>
              <span className="amount" style={{ fontSize: 12, fontWeight: 700, color: d.color }}>{d.value}</span>
            </div>
            <div style={{ height: 8, background: '#1c2330', borderRadius: 4, overflow: 'hidden' }}>
              <div style={{
                height: '100%',
                width: `${(d.value / max) * 100}%`,
                background: d.color,
                borderRadius: 4,
                opacity: hovered === null || hovered === i ? 1 : 0.3,
                transition: 'opacity 0.15s, width 0.5s',
              }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ── Analytics panel ─────────────────────────────────────────── */
function MemberAnalytics({ members }: { members: Member[] }) {
  const total = members.length
  if (total === 0) return null

  const male   = members.filter(m => m.gender === 'Male').length
  const female = members.filter(m => m.gender === 'Female').length
  const other  = members.filter(m => m.gender === 'Other').length

  const married   = members.filter(m => m.spouse.trim() !== '').length
  const unmarried = total - married

  const active    = members.filter(m => m.status === 'Active').length
  const inactive  = members.filter(m => m.status === 'Inactive').length
  const suspended = members.filter(m => m.status === 'Suspended').length

  const sig   = members.filter(m => m.signatureType === 'Signature').length
  const thumb = members.filter(m => m.signatureType === 'Thumb Impression').length

  const ages = members.map(m => calcAge(m.dateOfBirth))
  const ageGroups = [
    { label: 'Under 30',  value: ages.filter(a => a < 30).length,              color: '#60a5fa', sub: '< 30 yrs' },
    { label: '30 – 39',   value: ages.filter(a => a >= 30 && a < 40).length,   color: '#1a8cff', sub: '30–39 yrs' },
    { label: '40 – 49',   value: ages.filter(a => a >= 40 && a < 50).length,   color: '#a78bfa', sub: '40–49 yrs' },
    { label: '50 – 59',   value: ages.filter(a => a >= 50 && a < 60).length,   color: '#f0b429', sub: '50–59 yrs' },
    { label: '60 & above',value: ages.filter(a => a >= 60).length,             color: '#f85149', sub: '60+ yrs'   },
  ]

  const avgAge  = ages.length ? Math.round(ages.reduce((s, a) => s + a, 0) / ages.length) : 0
  const minAge  = ages.length ? Math.min(...ages) : 0
  const maxAge  = ages.length ? Math.max(...ages) : 0

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Section label */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ flex: 1, height: 1, background: '#30363d' }} />
        <span style={{ fontSize: 11, fontWeight: 700, color: '#8b949e', fontFamily: 'var(--font-display)', letterSpacing: '0.08em' }}>MEMBER ANALYTICS</span>
        <div style={{ flex: 1, height: 1, background: '#30363d' }} />
      </div>

      {/* Stat headline row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: 10 }}>
        {[
          { label: 'Total Members',   value: total,        color: '#1a8cff' },
          { label: 'Average Age',     value: avgAge + ' yrs', color: '#a78bfa', mono: false },
          { label: 'Youngest',        value: minAge + ' yrs', color: '#3fb950', mono: false },
          { label: 'Oldest',          value: maxAge + ' yrs', color: '#f0b429', mono: false },
          { label: 'Married',         value: married,      color: '#00d4aa' },
          { label: 'Admission Fees',  value: fmt(members.reduce((s,m) => s + m.admissionFee, 0)), color: '#f472b6', mono: true },
        ].map(s => (
          <div key={s.label} style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 10, padding: '12px 14px' }}>
            <div style={{ fontSize: 10, color: '#8b949e', marginBottom: 3, fontFamily: 'var(--font-display)' }}>{s.label}</div>
            <div className={(s as { mono?: boolean }).mono !== false ? 'amount' : ''} style={{ fontSize: 18, fontWeight: 800, color: s.color, fontFamily: 'var(--font-display)' }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Chart grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 16 }}>

        {/* Gender donut */}
        <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, padding: '20px 22px' }}>
          <DonutChart title="Gender Distribution" subtitle="members"
            data={[
              { label: 'Male',   value: male,   color: '#1a8cff' },
              { label: 'Female', value: female, color: '#f472b6' },
              ...(other > 0 ? [{ label: 'Other', value: other, color: '#a78bfa' }] : []),
            ]}
          />
        </div>

        {/* Marital status donut */}
        <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, padding: '20px 22px' }}>
          <DonutChart title="Marital Status" subtitle="members"
            data={[
              { label: 'Married',   value: married,   color: '#00d4aa' },
              { label: 'Unmarried', value: unmarried, color: '#a78bfa' },
            ]}
          />
        </div>

        {/* Age groups bar */}
        <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, padding: '20px 22px' }}>
          <HBarChart title="Age Groups" data={ageGroups} />
        </div>

        {/* Membership status bar */}
        <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, padding: '20px 22px' }}>
          <HBarChart title="Membership Status" maxOverride={total} data={[
            { label: 'Active',    value: active,    color: '#3fb950' },
            { label: 'Inactive',  value: inactive,  color: '#f0b429' },
            { label: 'Suspended', value: suspended, color: '#f85149' },
          ]} />
          {/* Admission type sub-chart */}
          <div style={{ marginTop: 20, paddingTop: 18, borderTop: '1px solid #21262d' }}>
            <HBarChart title="Signature Type" maxOverride={total} data={[
              { label: 'Signature',         value: sig,   color: '#1a8cff' },
              { label: 'Thumb Impression',  value: thumb, color: '#f0b429' },
            ]} />
          </div>
        </div>

      </div>
    </div>
  )
}

/* ── Age from DOB ───────────────────────────────────────────── */
const calcAge = (dob: string): number => {
  const parts = dob.split('/')
  if (parts.length < 3) return 0
  const birthDate = new Date(+parts[2], +parts[1] - 1, +parts[0])
  const today = new Date()
  let age = today.getFullYear() - birthDate.getFullYear()
  const m = today.getMonth() - birthDate.getMonth()
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) age--
  return isNaN(age) || age < 0 ? 0 : age
}

type Gender = 'Male' | 'Female' | 'Other'
type MemberStatus = 'Active' | 'Inactive' | 'Suspended'

type Member = {
  slno: number
  name: string            // First + surname
  fatherName: string
  dateOfAdmission: string
  dateOfBirth: string
  spouse: string          // empty if unmarried
  gender: Gender
  address: string         // detailed address
  nominee: string
  aadharNo: string
  admissionFee: number
  signatureType: 'Signature' | 'Thumb Impression'
  status: MemberStatus
  phone: string
  shares: number
  outstandingLoan: number
}

/* ── Seed ─────────────────────────────────────────────────────── */
const seed: Member[] = [
  { slno: 1,  name: 'John Michael',        fatherName: 'Samuel Michael',       dateOfAdmission: '14/03/2015', dateOfBirth: '12/06/1980', spouse: 'Mary John',          gender: 'Male',   address: 'No. 12, Church Road, XX Village, XX District – 797001', nominee: 'Mary John',        aadharNo: '2345 6789 0123', admissionFee: 100, signatureType: 'Signature',        status: 'Active',   phone: '9800000001', shares: 6, outstandingLoan: 0     },
  { slno: 2,  name: 'James Peters',         fatherName: 'George Peters',        dateOfAdmission: '14/03/2015', dateOfBirth: '05/09/1975', spouse: 'Susan James',        gender: 'Male',   address: 'No. 4, Main Street, XX Village, XX District – 797001',  nominee: 'Susan James',     aadharNo: '3456 7890 1234', admissionFee: 100, signatureType: 'Signature',        status: 'Active',   phone: '9800000002', shares: 6, outstandingLoan: 0     },
  { slno: 3,  name: 'Thomas Kiran',         fatherName: 'Robert Kiran',         dateOfAdmission: '14/03/2015', dateOfBirth: '22/11/1983', spouse: 'Anita Thomas',       gender: 'Male',   address: 'House No. 7, Temple Lane, XX Village – 797001',         nominee: 'Anita Thomas',    aadharNo: '4567 8901 2345', admissionFee: 100, signatureType: 'Thumb Impression', status: 'Active',   phone: '9800000003', shares: 6, outstandingLoan: 0     },
  { slno: 4,  name: 'Paul Rangsa',          fatherName: 'David Rangsa',         dateOfAdmission: '14/03/2015', dateOfBirth: '18/04/1978', spouse: 'Lily Paul',          gender: 'Male',   address: 'Vill. XX, P.O. XX, Dist. XX – 797002',                  nominee: 'Lily Paul',       aadharNo: '5678 9012 3456', admissionFee: 100, signatureType: 'Signature',        status: 'Active',   phone: '9800000004', shares: 6, outstandingLoan: 0     },
  { slno: 5,  name: 'David Meren',          fatherName: 'Joseph Meren',         dateOfAdmission: '14/03/2015', dateOfBirth: '30/07/1990', spouse: '',                   gender: 'Male',   address: 'C/O Joseph Meren, XX Village – 797001',                 nominee: 'Joseph Meren',    aadharNo: '6789 0123 4567', admissionFee: 100, signatureType: 'Thumb Impression', status: 'Active',   phone: '9800000005', shares: 6, outstandingLoan: 0     },
  { slno: 6,  name: 'Peter Sumi',           fatherName: 'Matthew Sumi',         dateOfAdmission: '14/03/2015', dateOfBirth: '14/02/1985', spouse: 'Ruth Peter',         gender: 'Male',   address: 'Lane No. 3, XX Colony, XX Town – 797001',               nominee: 'Ruth Peter',      aadharNo: '7890 1234 5678', admissionFee: 100, signatureType: 'Signature',        status: 'Active',   phone: '9800000006', shares: 6, outstandingLoan: 0     },
  { slno: 7,  name: 'Andrew Lotha',         fatherName: 'Luke Lotha',           dateOfAdmission: '14/03/2015', dateOfBirth: '09/10/1979', spouse: 'Grace Andrew',       gender: 'Male',   address: 'XX Village, Near Primary School – 797001',              nominee: 'Grace Andrew',    aadharNo: '8901 2345 6789', admissionFee: 100, signatureType: 'Signature',        status: 'Active',   phone: '9800000007', shares: 6, outstandingLoan: 0     },
  { slno: 8,  name: 'Rosemary Ao',          fatherName: 'Benjamin Ao',          dateOfAdmission: '14/03/2015', dateOfBirth: '25/03/1988', spouse: 'Samuel Ao',          gender: 'Female', address: 'Ao Colony, XX Village – 797001',                        nominee: 'Samuel Ao',       aadharNo: '9012 3456 7890', admissionFee: 100, signatureType: 'Thumb Impression', status: 'Active',   phone: '9800000008', shares: 6, outstandingLoan: 0     },
  { slno: 9,  name: 'Mark Zeliang',         fatherName: 'Simon Zeliang',        dateOfAdmission: '14/03/2015', dateOfBirth: '07/01/1982', spouse: 'Esther Mark',        gender: 'Male',   address: 'Zeliang Basti, XX Village – 797003',                    nominee: 'Esther Mark',     aadharNo: '0123 4567 8901', admissionFee: 100, signatureType: 'Signature',        status: 'Active',   phone: '9800000009', shares: 6, outstandingLoan: 0     },
  { slno: 10, name: 'Luke Sangtam',         fatherName: 'Philip Sangtam',       dateOfAdmission: '14/03/2015', dateOfBirth: '19/08/1986', spouse: 'Mercy Luke',         gender: 'Male',   address: 'Sangtam Colony, XX Village – 797001',                   nominee: 'Mercy Luke',      aadharNo: '1234 5678 9012', admissionFee: 100, signatureType: 'Thumb Impression', status: 'Active',   phone: '9800000010', shares: 6, outstandingLoan: 0     },
  { slno: 11, name: 'Matthew Yimchunger',   fatherName: 'Nathaniel Yimchunger', dateOfAdmission: '14/03/2015', dateOfBirth: '03/12/1977', spouse: 'Sarah Matthew',      gender: 'Male',   address: 'Yimchunger Quarter, XX Village – 797004',               nominee: 'Sarah Matthew',   aadharNo: '2345 6789 1234', admissionFee: 100, signatureType: 'Signature',        status: 'Active',   phone: '9800000011', shares: 6, outstandingLoan: 10000 },
  { slno: 12, name: 'Simon Khiamniungan',   fatherName: 'Elijah Khiamniungan',  dateOfAdmission: '14/03/2015', dateOfBirth: '28/05/1984', spouse: '',                   gender: 'Male',   address: 'KN Basti, XX Village – 797001',                         nominee: 'Elijah Khiamniungan', aadharNo: '3456 7891 2345', admissionFee: 100, signatureType: 'Thumb Impression', status: 'Active', phone: '9800000012', shares: 6, outstandingLoan: 10000 },
  { slno: 13, name: 'Priya Phom',           fatherName: 'Timothy Phom',         dateOfAdmission: '14/03/2015', dateOfBirth: '11/09/1991', spouse: 'Rajan Phom',         gender: 'Female', address: 'Phom Colony, XX Town – 797002',                         nominee: 'Rajan Phom',      aadharNo: '4567 8902 3456', admissionFee: 100, signatureType: 'Thumb Impression', status: 'Active',   phone: '9800000013', shares: 6, outstandingLoan: 10000 },
  { slno: 14, name: 'Bartholomew Chang',    fatherName: 'Ezra Chang',           dateOfAdmission: '14/03/2015', dateOfBirth: '16/04/1976', spouse: 'Lena Bartholomew',   gender: 'Male',   address: 'Chang Village, XX District – 797005',                   nominee: 'Lena Bartholomew', aadharNo: '5678 9013 4567', admissionFee: 100, signatureType: 'Signature',       status: 'Active',   phone: '9800000014', shares: 6, outstandingLoan: 10000 },
  { slno: 15, name: 'Thaddaeus Rengma',     fatherName: 'Isaiah Rengma',        dateOfAdmission: '14/03/2015', dateOfBirth: '02/02/1980', spouse: 'Deborah Thaddaeus',  gender: 'Male',   address: 'Rengma Colony, XX Village – 797001',                    nominee: 'Deborah Thaddaeus', aadharNo: '6789 0124 5678', admissionFee: 100, signatureType: 'Signature',      status: 'Active',   phone: '9800000015', shares: 6, outstandingLoan: 10000 },
  { slno: 16, name: 'Naga Trader Singh',    fatherName: 'Mohan Singh',          dateOfAdmission: '14/04/2015', dateOfBirth: '23/07/1972', spouse: 'Kamla Singh',        gender: 'Male',   address: 'Market Road, XX Town – 797002',                         nominee: 'Kamla Singh',     aadharNo: '7890 1235 6789', admissionFee: 100, signatureType: 'Signature',        status: 'Active',   phone: '9800000016', shares: 6, outstandingLoan: 0     },
  { slno: 17, name: 'Elijah Wangchu',       fatherName: 'Jeremiah Wangchu',     dateOfAdmission: '14/04/2015', dateOfBirth: '14/11/1995', spouse: '',                   gender: 'Male',   address: 'Wangchu Basti, XX Village – 797001',                    nominee: 'Jeremiah Wangchu', aadharNo: '8901 2346 7890', admissionFee: 100, signatureType: 'Thumb Impression', status: 'Active',   phone: '9800000017', shares: 6, outstandingLoan: 0    },
  { slno: 18, name: 'Elisha Longkumer',     fatherName: 'Hosea Longkumer',      dateOfAdmission: '14/04/2015', dateOfBirth: '08/06/1993', spouse: '',                   gender: 'Female', address: 'Longkumer Colony, XX Village – 797003',                 nominee: 'Hosea Longkumer', aadharNo: '9012 3457 8901', admissionFee: 100, signatureType: 'Thumb Impression', status: 'Inactive', phone: '9800000018', shares: 6, outstandingLoan: 0    },
]

const statusBadge = (s: MemberStatus) => {
  const map: Record<MemberStatus, string> = { Active: 'badge-green', Inactive: 'badge-yellow', Suspended: 'badge-red' }
  return (
    <span className={map[s]} style={{ padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-display)' }}>
      {s}
    </span>
  )
}

const genderIcon = (g: Gender) => g === 'Female' ? '♀' : g === 'Male' ? '♂' : '⚧'

const blankDraft = (): Partial<Member> => ({
  gender: 'Male', signatureType: 'Signature', status: 'Active',
  shares: 6, admissionFee: 100, outstandingLoan: 0,
})

/* ════════════════════════════════════════════════════════════════ */
export default function MembershipRegister() {
  const [members, setMembers]     = useState<Member[]>(seed)
  const [search, setSearch]       = useState('')
  const [statusF, setStatusF]     = useState<MemberStatus | 'All'>('All')
  const [genderF, setGenderF]     = useState<Gender | 'All'>('All')
  const [selected, setSelected]   = useState<Member | null>(null)
  const [showAdd, setShowAdd]     = useState(false)
  const [draft, setDraft]         = useState<Partial<Member>>(blankDraft())

  const filtered = members.filter(m => {
    if (statusF !== 'All' && m.status !== statusF) return false
    if (genderF !== 'All' && m.gender !== genderF) return false
    const q = search.toLowerCase()
    return !q || m.name.toLowerCase().includes(q) || m.fatherName.toLowerCase().includes(q) || m.aadharNo.includes(q) || m.phone.includes(q)
  })

  const totalFees = members.reduce((s, m) => s + m.admissionFee, 0)
  const activeCount = members.filter(m => m.status === 'Active').length

  const d = (k: keyof Member) => (val: unknown) => setDraft(prev => ({ ...prev, [k]: val }))

  const saveMember = () => {
    if (!draft.name) return
    const m: Member = {
      slno: members.length + 1,
      name: draft.name || '',
      fatherName: draft.fatherName || '',
      dateOfAdmission: draft.dateOfAdmission || '',
      dateOfBirth: draft.dateOfBirth || '',
      spouse: draft.spouse || '',
      gender: draft.gender as Gender || 'Male',
      address: draft.address || '',
      nominee: draft.nominee || '',
      aadharNo: draft.aadharNo || '',
      admissionFee: draft.admissionFee ?? 100,
      signatureType: draft.signatureType as Member['signatureType'] || 'Signature',
      status: draft.status as MemberStatus || 'Active',
      phone: draft.phone || '',
      shares: draft.shares ?? 6,
      outstandingLoan: 0,
    }
    setMembers(prev => [...prev, m])
    setDraft(blankDraft())
    setShowAdd(false)
  }

  const Field = ({ label, value, mono }: { label: string; value: string | number; mono?: boolean }) => (
    <div style={{ borderBottom: '1px solid #21262d', paddingBottom: 8, marginBottom: 0 }}>
      <div style={{ fontSize: 10, color: '#8b949e', marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 13, color: '#e6edf3', fontWeight: 500, fontFamily: mono ? 'var(--font-mono)' : undefined }}>{value || '—'}</div>
    </div>
  )

  return (
    <div style={{ maxWidth: 1400, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 22 }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, color: '#e6edf3', margin: 0 }}>Membership Register</h1>
          <p style={{ color: '#8b949e', fontSize: 13, margin: '4px 0 0' }}>XX IMPCS Ltd. · Member records &amp; admission details</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-ghost" style={{ fontSize: 12 }} onClick={() =>
            downloadCSV('impcs-membership-register.csv', [
              'Sl.No','Name of Member','Father\'s Name','Date of Admission','Date of Birth','Age',
              'Spouse','Gender','Detailed Address','Name of Nominee','Aadhar No.',
              'Admission Fee (₹)','Signature/Thumb Impression','Status'
            ], [filtered.map(m => [
              m.slno, m.name, m.fatherName, m.dateOfAdmission, m.dateOfBirth, calcAge(m.dateOfBirth),
              m.spouse || 'Unmarried', m.gender, m.address, m.nominee, m.aadharNo,
              m.admissionFee, m.signatureType, m.status
            ])])
          }>⬇ CSV</button>
          <button className="btn-primary" onClick={() => { setShowAdd(v => !v); setSelected(null) }}>+ Add Member</button>
        </div>
      </div>

      {/* KPI strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: 14 }}>
        {[
          { label: 'Total Members',       value: String(members.length), color: '#1a8cff', mono: false },
          { label: 'Active Members',      value: String(activeCount),    color: '#3fb950', mono: false },
          { label: 'Male Members',        value: String(members.filter(m => m.gender === 'Male').length),   color: '#60a5fa', mono: false },
          { label: 'Female Members',      value: String(members.filter(m => m.gender === 'Female').length), color: '#f472b6', mono: false },
          { label: 'Total Admission Fees',value: fmt(totalFees),         color: '#00d4aa', mono: true  },
          { label: 'Avg Age',             value: Math.round(members.reduce((s,m) => s + calcAge(m.dateOfBirth), 0) / members.length) + ' yrs', color: '#a78bfa', mono: false },
        ].map(c => (
          <div key={c.label} style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 10, padding: '14px 18px' }}>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>{c.label}</div>
            <div className={c.mono ? 'amount' : ''} style={{ fontSize: 20, fontWeight: 700, color: c.color }}>{c.value}</div>
          </div>
        ))}
      </div>

      {/* Analytics infographics */}
      <MemberAnalytics members={members} />

      {/* Controls */}
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
        <input placeholder="Search name, father's name, Aadhar, phone…" value={search} onChange={e => setSearch(e.target.value)} style={{ width: 280 }} />
        <div style={{ display: 'flex', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, padding: 3, gap: 1 }}>
          {(['All','Active','Inactive','Suspended'] as const).map(s => (
            <button key={s} onClick={() => setStatusF(s)} style={{
              background: statusF === s ? '#1a8cff' : 'transparent', color: statusF === s ? 'white' : '#8b949e',
              borderTop: 'none', borderLeft: 'none', borderRight: 'none', borderBottom: 'none',
              borderRadius: 5, padding: '5px 10px', fontSize: 12, fontWeight: 600, fontFamily: 'var(--font-display)', cursor: 'pointer',
            }}>{s}</button>
          ))}
        </div>
        <div style={{ display: 'flex', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, padding: 3, gap: 1 }}>
          {(['All','Male','Female'] as const).map(g => (
            <button key={g} onClick={() => setGenderF(g)} style={{
              background: genderF === g ? '#1a8cff' : 'transparent', color: genderF === g ? 'white' : '#8b949e',
              borderTop: 'none', borderLeft: 'none', borderRight: 'none', borderBottom: 'none',
              borderRadius: 5, padding: '5px 10px', fontSize: 12, fontWeight: 600, fontFamily: 'var(--font-display)', cursor: 'pointer',
            }}>{g}</button>
          ))}
        </div>
        <div style={{ marginLeft: 'auto', fontSize: 12, color: '#8b949e' }}>{filtered.length} of {members.length} members</div>
      </div>

      {/* Add member form */}
      {showAdd && (
        <div style={{ background: '#161b22', border: '1px solid #1a8cff44', borderRadius: 12, padding: 22 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: '#e6edf3', marginBottom: 16 }}>
            New Member — Admission Form
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))', gap: 14 }}>
            {[
              { label: 'Full Name (with Surname) *', key: 'name' },
              { label: "Father's Name *",            key: 'fatherName' },
              { label: 'Date of Admission',          key: 'dateOfAdmission', type: 'date' },
              { label: 'Date of Birth',              key: 'dateOfBirth',     type: 'date' },
              { label: 'Spouse Name (if married)',   key: 'spouse' },
              { label: 'Detailed Address',           key: 'address' },
              { label: 'Name of Nominee',            key: 'nominee' },
              { label: 'Aadhar No.',                 key: 'aadharNo' },
              { label: 'Phone',                      key: 'phone' },
              { label: 'Admission Fee (₹)',          key: 'admissionFee', type: 'number' },
            ].map(f => (
              <div key={f.key}>
                <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>{f.label}</div>
                <input type={f.type || 'text'} value={(draft as Record<string, unknown>)[f.key] as string ?? ''}
                  onChange={e => d(f.key as keyof Member)(f.type === 'number' ? +e.target.value : e.target.value)}
                  style={{ width: '100%' }} />
              </div>
            ))}
            {/* Select fields */}
            <div>
              <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>Gender</div>
              <select value={draft.gender || 'Male'} onChange={e => d('gender')(e.target.value)} style={{ width: '100%' }}>
                {(['Male','Female','Other'] as Gender[]).map(g => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div>
              <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>Signature / Thumb Impression</div>
              <select value={draft.signatureType || 'Signature'} onChange={e => d('signatureType')(e.target.value)} style={{ width: '100%' }}>
                <option>Signature</option>
                <option>Thumb Impression</option>
              </select>
            </div>
            <div>
              <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>Status</div>
              <select value={draft.status || 'Active'} onChange={e => d('status')(e.target.value)} style={{ width: '100%' }}>
                {(['Active','Inactive','Suspended'] as MemberStatus[]).map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          {/* Age preview */}
          {draft.dateOfBirth && (
            <div style={{ marginTop: 12, display: 'inline-flex', gap: 6, alignItems: 'center', background: '#1a8cff11', border: '1px solid #1a8cff33', borderRadius: 8, padding: '8px 14px', fontSize: 12 }}>
              <span style={{ color: '#8b949e' }}>Calculated Age:</span>
              <strong style={{ color: '#1a8cff' }}>{calcAge((() => { const d = new Date(draft.dateOfBirth!); return `${d.getDate().toString().padStart(2,'0')}/${(d.getMonth()+1).toString().padStart(2,'0')}/${d.getFullYear()}` })())} years</strong>
            </div>
          )}
          <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
            <button className="btn-primary" onClick={saveMember}>Save Member</button>
            <button className="btn-ghost" onClick={() => setShowAdd(false)}>Cancel</button>
          </div>
        </div>
      )}

      {/* Table + detail panel */}
      <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 360px' : '1fr', gap: 16 }}>

        {/* Main table */}
        <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden' }}>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style={{ width: 44 }}>Sl.No</th>
                  <th>Name of Member</th>
                  <th>Father's Name</th>
                  <th>Date of Admission</th>
                  <th>Date of Birth</th>
                  <th style={{ textAlign: 'right' }}>Age</th>
                  <th>Spouse</th>
                  <th>Gender</th>
                  <th>Detailed Address</th>
                  <th>Name of Nominee</th>
                  <th>Aadhar No.</th>
                  <th style={{ textAlign: 'right' }}>Admission Fee</th>
                  <th>Signature / Thumb</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(m => (
                  <tr key={m.slno}
                    onClick={() => setSelected(selected?.slno === m.slno ? null : m)}
                    style={{ cursor: 'pointer', background: selected?.slno === m.slno ? '#1a8cff0d' : undefined }}
                  >
                    <td className="amount" style={{ color: '#8b949e' }}>{m.slno}</td>
                    <td style={{ fontWeight: 700, whiteSpace: 'nowrap' }}>{m.name}</td>
                    <td style={{ color: '#8b949e', fontSize: 12, whiteSpace: 'nowrap' }}>{m.fatherName}</td>
                    <td className="amount" style={{ fontSize: 12, color: '#8b949e' }}>{m.dateOfAdmission}</td>
                    <td className="amount" style={{ fontSize: 12, color: '#8b949e' }}>{m.dateOfBirth}</td>
                    <td className="amount" style={{ textAlign: 'right', fontWeight: 600 }}>{calcAge(m.dateOfBirth)}</td>
                    <td style={{ fontSize: 12, color: m.spouse ? '#e6edf3' : '#8b949e' }}>{m.spouse || <em style={{ color: '#30363d' }}>Unmarried</em>}</td>
                    <td>
                      <span style={{ fontSize: 13 }}>{genderIcon(m.gender)}</span>
                      <span style={{ fontSize: 11, color: '#8b949e', marginLeft: 4 }}>{m.gender}</span>
                    </td>
                    <td style={{ fontSize: 11, color: '#8b949e', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.address}</td>
                    <td style={{ fontSize: 12, whiteSpace: 'nowrap' }}>{m.nominee}</td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: '#8b949e', letterSpacing: '0.05em' }}>{m.aadharNo}</td>
                    <td className="amount" style={{ textAlign: 'right', color: '#00d4aa', fontWeight: 600 }}>{fmt(m.admissionFee)}</td>
                    <td>
                      <span style={{
                        fontSize: 11, fontWeight: 600, fontFamily: 'var(--font-display)',
                        ...(m.signatureType === 'Signature'
                          ? { color: '#1a8cff' }
                          : { color: '#f0b429' })
                      }}>
                        {m.signatureType === 'Signature' ? '✍ Signature' : '👍 Thumb'}
                      </span>
                    </td>
                    <td>{statusBadge(m.status)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={11} style={{ color: '#8b949e' }}>Total ({filtered.length} members)</td>
                  <td className="amount" style={{ textAlign: 'right', color: '#00d4aa' }}>
                    {fmt(filtered.reduce((s, m) => s + m.admissionFee, 0))}
                  </td>
                  <td colSpan={2} />
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Detail panel */}
        {selected && (
          <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, padding: 22, alignSelf: 'start', display: 'flex', flexDirection: 'column', gap: 14 }}>

            {/* Header row */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: '#e6edf3', lineHeight: 1.2 }}>{selected.name}</div>
                <div style={{ fontSize: 12, color: '#8b949e', marginTop: 3 }}>Member #{selected.slno}</div>
              </div>
              <button onClick={() => setSelected(null)} style={{
                background: 'transparent', borderTop: 'none', borderLeft: 'none', borderRight: 'none', borderBottom: 'none',
                color: '#8b949e', cursor: 'pointer', fontSize: 18, lineHeight: 1, padding: 4,
              }}>✕</button>
            </div>

            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {statusBadge(selected.status)}
              <span style={{ background: '#1a8cff18', color: '#1a8cff', border: '1px solid #1a8cff44', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>
                {genderIcon(selected.gender)} {selected.gender}
              </span>
              <span style={{ background: '#a78bfa18', color: '#a78bfa', border: '1px solid #a78bfa44', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>
                Age {calcAge(selected.dateOfBirth)}
              </span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <Field label="Father's Name"        value={selected.fatherName} />
              <Field label="Date of Admission"    value={selected.dateOfAdmission} />
              <Field label="Date of Birth"        value={selected.dateOfBirth} />
              <Field label="Spouse"               value={selected.spouse || 'Unmarried'} />
              <Field label="Detailed Address"     value={selected.address} />
              <Field label="Name of Nominee"      value={selected.nominee} />
              <Field label="Aadhar No."           value={selected.aadharNo} mono />
              <Field label="Phone"                value={selected.phone} />
            </div>

            {/* Financial boxes */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div style={{ background: '#00d4aa18', border: '1px solid #00d4aa33', borderRadius: 8, padding: '12px 14px', textAlign: 'center' }}>
                <div style={{ fontSize: 10, color: '#8b949e' }}>Admission Fee</div>
                <div className="amount" style={{ fontSize: 16, fontWeight: 700, color: '#00d4aa', marginTop: 4 }}>{fmt(selected.admissionFee)}</div>
              </div>
              <div style={{ background: '#a78bfa18', border: '1px solid #a78bfa33', borderRadius: 8, padding: '12px 14px', textAlign: 'center' }}>
                <div style={{ fontSize: 10, color: '#8b949e' }}>Share Capital</div>
                <div className="amount" style={{ fontSize: 16, fontWeight: 700, color: '#a78bfa', marginTop: 4 }}>{fmt(selected.shares * 400)}</div>
                <div style={{ fontSize: 10, color: '#8b949e' }}>{selected.shares} shares × ₹400</div>
              </div>
            </div>

            {/* Signature box */}
            <div style={{
              border: '1px dashed #30363d', borderRadius: 8, padding: '16px',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
            }}>
              <div style={{ fontSize: 28 }}>{selected.signatureType === 'Signature' ? '✍️' : '👍'}</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#8b949e', fontFamily: 'var(--font-display)' }}>{selected.signatureType}</div>
              <div style={{ fontSize: 11, color: '#30363d' }}>of {selected.name}</div>
            </div>

            {selected.outstandingLoan > 0 && (
              <div style={{ background: '#f0b42918', border: '1px solid #f0b42933', borderRadius: 8, padding: '10px 14px' }}>
                <div style={{ fontSize: 10, color: '#8b949e' }}>Outstanding Loan</div>
                <div className="amount" style={{ fontSize: 16, fontWeight: 700, color: '#f0b429' }}>{fmt(selected.outstandingLoan)}</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
