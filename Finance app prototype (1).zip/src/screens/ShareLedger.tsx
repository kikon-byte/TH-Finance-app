import { useState } from 'react'
import { downloadCSV } from '../utils/downloadCSV'

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

type ShareEntry = { slno: number; name: string; date: string; noShares: number; valuePerShare: number; amountWithheld: number; amountWithdrawn: number; balance: number; period: string }

const batch1: ShareEntry[] = Array.from({ length: 30 }, (_, i) => ({
  slno: i + 1,
  name: i === 0 ? 'John' : `Subscriber ${i + 1}`,
  date: '14/03/2015',
  noShares: 6,
  valuePerShare: 400,
  amountWithheld: 2400,
  amountWithdrawn: 0,
  balance: 2400,
  period: '31/3/2024',
}))

const batch2: ShareEntry[] = Array.from({ length: 13 }, (_, i) => ({
  slno: i + 1,
  name: `Subscriber ${i + 31}`,
  date: '14/04/2015',
  noShares: 6,
  valuePerShare: 400,
  amountWithheld: 2400,
  amountWithdrawn: 0,
  balance: 2400,
  period: '31/3/2025',
}))

export default function ShareLedger() {
  const [period, setPeriod] = useState<'2024' | '2025'>('2024')
  const [search, setSearch] = useState('')

  const data = period === '2024' ? batch1 : batch2
  const filtered = data.filter(s => s.name.toLowerCase().includes(search.toLowerCase()))

  const totalShares = filtered.reduce((s, e) => s + e.noShares, 0)
  const totalWithheld = filtered.reduce((s, e) => s + e.amountWithheld, 0)
  const totalBalance = filtered.reduce((s, e) => s + e.balance, 0)

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, color: '#e6edf3', margin: 0 }}>
          Share Ledger Register
        </h1>
        <p style={{ color: '#8b949e', fontSize: 13, margin: '4px 0 0' }}>
          XX Agri &amp; Allied C.S Ltd. XX Town · Share Instalment (Record)
        </p>
      </div>

      {/* Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        {[
          { label: 'Total Subscribers', value: filtered.length + ' members', color: '#1a8cff', raw: false },
          { label: 'Total Shares', value: totalShares + ' nos', color: '#a78bfa', raw: false },
          { label: 'Total Share Capital', value: fmt(totalWithheld), color: '#00d4aa', raw: true },
          { label: 'Total Balance', value: fmt(totalBalance), color: '#3fb950', raw: true },
        ].map(c => (
          <div key={c.label} style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 10, padding: '14px 18px' }}>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>{c.label}</div>
            <div className={c.raw ? 'amount' : ''} style={{ fontSize: 20, fontWeight: 700, color: c.color }}>{c.value}</div>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ display: 'flex', background: '#161b22', border: '1px solid #30363d', borderRadius: 10, padding: 4, gap: 2 }}>
          {(['2024', '2025'] as const).map(p => (
            <button key={p} onClick={() => setPeriod(p)} style={{
              background: period === p ? '#1a8cff' : 'transparent',
              color: period === p ? 'white' : '#8b949e',
              border: 'none', borderRadius: 7,
              padding: '6px 18px', fontSize: 12.5, fontWeight: 600, fontFamily: 'var(--font-display)',
              cursor: 'pointer', transition: 'all 0.15s',
            }}>As on 31/3/{p}</button>
          ))}
        </div>
        <input placeholder="Search subscriber..." value={search} onChange={e => setSearch(e.target.value)} style={{ width: 200 }} />
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
          <button className="btn-ghost" onClick={() =>
            downloadCSV(
              `impcs-share-ledger-${period}.csv`,
              ['Sl.No','Name','Date','No of Shares','Value per Share (₹)','Amount Withheld (₹)','Amount Withdrawn','Balance (₹)'],
              [filtered.map(s => [s.slno, s.name, s.date, s.noShares, s.valuePerShare, s.amountWithheld, 'Nil', s.balance])],
            )
          }>⬇ CSV</button>
          <button className="btn-primary">+ Add Subscriber</button>
        </div>
      </div>

      {/* Audit notes */}
      <div style={{ background: '#a78bfa11', border: '1px solid #a78bfa33', borderRadius: 10, padding: '12px 18px', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
        <span style={{ color: '#a78bfa' }}>◈</span>
        <div style={{ fontSize: 12, color: '#8b949e' }}>
          <strong style={{ color: '#a78bfa' }}>Audit:</strong>&nbsp;
          Share Instalment (Record) · Share Certificate · Can be changed or not · Instalment
        </div>
      </div>

      {/* Table */}
      <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden' }}>
        <div style={{ padding: '12px 20px', borderBottom: '1px solid #30363d', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, color: '#8b949e' }}>
          Share Ledger · As on 31/3/{period} · {filtered.length} subscribers
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Sl.No</th>
                <th>Name of Share Subscriber</th>
                <th>Date</th>
                <th style={{ textAlign: 'right' }}>No of Shares</th>
                <th style={{ textAlign: 'right' }}>Value of Share</th>
                <th style={{ textAlign: 'right' }}>Amount Withheld</th>
                <th style={{ textAlign: 'right' }}>Amount Withdrawal</th>
                <th style={{ textAlign: 'right' }}>Balance</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(s => (
                <tr key={s.slno}>
                  <td className="amount" style={{ color: '#8b949e' }}>{s.slno}</td>
                  <td style={{ fontWeight: 500 }}>{s.name}</td>
                  <td className="amount" style={{ fontSize: 12, color: '#8b949e' }}>{s.date}</td>
                  <td className="amount" style={{ textAlign: 'right' }}>{s.noShares} Nos.</td>
                  <td className="amount" style={{ textAlign: 'right' }}>{fmt(s.valuePerShare)}</td>
                  <td className="amount" style={{ textAlign: 'right', color: '#00d4aa', fontWeight: 600 }}>{fmt(s.amountWithheld)}</td>
                  <td className="amount" style={{ textAlign: 'right', color: '#8b949e' }}>Nil</td>
                  <td className="amount" style={{ textAlign: 'right', color: '#3fb950', fontWeight: 600 }}>{fmt(s.balance)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3}>Total</td>
                <td className="amount" style={{ textAlign: 'right' }}>{totalShares} Nos.</td>
                <td />
                <td className="amount" style={{ textAlign: 'right', color: '#00d4aa' }}>{fmt(totalWithheld)}</td>
                <td className="amount" style={{ textAlign: 'right', color: '#8b949e' }}>Nil</td>
                <td className="amount" style={{ textAlign: 'right', color: '#3fb950' }}>{fmt(totalBalance)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  )
}
