import { useState } from 'react'
import { downloadCSV } from '../utils/downloadCSV'

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

const stats = [
  { label: 'Total Loans Disbursed', value: 150000, sub: '15 active members', color: '#1a8cff', icon: '₹', trend: '+₹10,000 this month' },
  { label: 'Total Recovered', value: 110000, sub: 'Principal + ₹10,000 interest', color: '#00d4aa', icon: '↑', trend: '73.3% recovery rate' },
  { label: 'Outstanding Principal', value: 50000, sub: '5 members pending', color: '#f0b429', icon: '!', trend: 'Due: Sep 2026' },
  { label: 'Total Share Capital', value: 72000, sub: '30 shareholders @₹2,400 each', color: '#a78bfa', icon: '◈', trend: '30 × 6 shares' },
]

const recentTransactions = [
  { date: '25/03/2025', particulars: 'Temporary loan refunded', receipt: 120000, payment: null },
  { date: '25/03/2025', particulars: 'Meeting Expense', receipt: null, payment: 2000 },
  { date: '25/03/2025', particulars: 'Honorarium to Chairman', receipt: null, payment: 11000 },
  { date: '25/03/2025', particulars: 'Misc. expenses', receipt: null, payment: 1268 },
  { date: '25/03/2025', particulars: 'Printing & Stationery', receipt: null, payment: 2200 },
  { date: '31/03/2025', particulars: 'Audit & NSCU Fee', receipt: null, payment: 400 },
  { date: '19/06/2024', particulars: 'Sale of Broiler 50 nos × 2kg @ ₹280', receipt: 28000, payment: null },
  { date: '19/07/2024', particulars: 'Sale of Broiler 20 nos × 3kg @ ₹280', receipt: 16800, payment: null },
]

const loanSummary = [
  { name: 'John (Batch 1)', disbursed: '05/04/23', amount: 10000, due: '05/04/24', status: 'Cleared' },
  { name: 'Member 2', disbursed: '05/04/23', amount: 10000, due: '05/04/24', status: 'Cleared' },
  { name: 'Member 3', disbursed: '05/04/23', amount: 10000, due: '05/04/24', status: 'Cleared' },
  { name: 'Member 11', disbursed: '15/09/24', amount: 10000, due: '15/09/26', status: 'Pending' },
  { name: 'Member 12', disbursed: '15/09/24', amount: 10000, due: '15/09/26', status: 'Pending' },
  { name: 'Member 13', disbursed: '15/09/24', amount: 10000, due: '15/09/26', status: 'Pending' },
  { name: 'Member 14', disbursed: '15/09/24', amount: 10000, due: '15/09/26', status: 'Pending' },
  { name: 'Member 15', disbursed: '15/09/24', amount: 10000, due: '15/09/26', status: 'Pending' },
]

const statusBadge = (s: string) => (
  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold font-display ${
    s === 'Cleared' ? 'badge-green' : s === 'Pending' ? 'badge-yellow' : 'badge-red'
  }`}>{s}</span>
)

export default function Dashboard() {
  const [filter, setFilter] = useState<'all' | 'receipts' | 'payments'>('all')

  const filtered = recentTransactions.filter(t => {
    if (filter === 'receipts') return t.receipt
    if (filter === 'payments') return t.payment
    return true
  })

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 24 }}>
      {/* Header */}
      <div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 26, color: '#e6edf3', margin: 0 }}>
          Financial Overview
        </h1>
        <p style={{ color: '#8b949e', fontSize: 13, margin: '4px 0 0' }}>
          XX IMPCS Ltd. · FY 2024–25 · As on 31/03/2025
        </p>
        <button className="btn-ghost" style={{ marginTop: 8, fontSize: 12 }} onClick={() =>
          downloadCSV('impcs-dashboard-summary.csv',
            ['Metric', 'Value'],
            [[
              ['Total Loans Disbursed', '₹1,50,000'],
              ['Total Recovered', '₹1,10,000'],
              ['Outstanding Principal', '₹50,000'],
              ['Total Share Capital', '₹72,000'],
              ['Grand Total Day Book', '₹6,34,375'],
              ['Closing Balance', '₹14,103'],
            ]])
        }>⬇ Download Summary CSV</button>
      </div>

      {/* Stats grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 16 }}>
        {stats.map(s => (
          <div key={s.label} className="stat-card" style={{ padding: '20px 22px' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
              <div style={{
                width: 36, height: 36,
                background: s.color + '22',
                border: `1px solid ${s.color}44`,
                borderRadius: 10,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, color: s.color,
              }}>{s.icon}</div>
            </div>
            <div className="amount" style={{ fontSize: 24, fontWeight: 700, color: '#e6edf3', letterSpacing: '-0.5px' }}>
              {fmt(s.value)}
            </div>
            <div style={{ color: '#8b949e', fontSize: 12, marginTop: 2 }}>{s.label}</div>
            <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid #30363d', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 11, color: '#8b949e' }}>{s.sub}</span>
              <span style={{ fontSize: 11, color: s.color, fontWeight: 600 }}>{s.trend}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Two columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Recent transactions */}
        <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid #30363d', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: '#e6edf3' }}>Recent Transactions</div>
              <div style={{ fontSize: 11, color: '#8b949e' }}>Day Book · March 2025</div>
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              {(['all', 'receipts', 'payments'] as const).map(f => (
                <button key={f} onClick={() => setFilter(f)} className={filter === f ? 'btn-primary' : 'btn-ghost'} style={{ padding: '4px 10px', fontSize: 11, textTransform: 'capitalize' }}>
                  {f}
                </button>
              ))}
            </div>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Particulars</th>
                  <th style={{ textAlign: 'right' }}>Receipt</th>
                  <th style={{ textAlign: 'right' }}>Payment</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((t, i) => (
                  <tr key={i}>
                    <td className="amount" style={{ fontSize: 12, color: '#8b949e' }}>{t.date}</td>
                    <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.particulars}</td>
                    <td className="amount" style={{ textAlign: 'right', color: '#3fb950' }}>
                      {t.receipt ? fmt(t.receipt) : '—'}
                    </td>
                    <td className="amount" style={{ textAlign: 'right', color: '#f85149' }}>
                      {t.payment ? fmt(t.payment) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Loan status */}
        <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid #30363d' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: '#e6edf3' }}>Loan Status Summary</div>
            <div style={{ fontSize: 11, color: '#8b949e' }}>Own Funds · 10% p.a. · 15 members</div>
          </div>

          {/* Progress bar */}
          <div style={{ padding: '16px 20px', borderBottom: '1px solid #30363d' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#8b949e', marginBottom: 6 }}>
              <span>Recovery Progress</span>
              <span className="amount" style={{ color: '#00d4aa', fontWeight: 600 }}>73.3%</span>
            </div>
            <div style={{ height: 8, background: '#1c2330', borderRadius: 4, overflow: 'hidden' }}>
              <div style={{ height: '100%', width: '73.3%', background: 'linear-gradient(90deg, #1a8cff, #00d4aa)', borderRadius: 4 }} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginTop: 6 }}>
              <span style={{ color: '#3fb950' }}>Recovered: ₹1,10,000</span>
              <span style={{ color: '#f0b429' }}>Pending: ₹50,000</span>
            </div>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Member</th>
                  <th>Disbursed</th>
                  <th style={{ textAlign: 'right' }}>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {loanSummary.map((l, i) => (
                  <tr key={i}>
                    <td style={{ fontWeight: 500 }}>{l.name}</td>
                    <td className="amount" style={{ fontSize: 12, color: '#8b949e' }}>{l.disbursed}</td>
                    <td className="amount" style={{ textAlign: 'right' }}>{fmt(l.amount)}</td>
                    <td>{statusBadge(l.status)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Bottom info strip */}
      <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, padding: '16px 24px', display: 'flex', flexWrap: 'wrap', gap: 24 }}>
        {[
          { label: 'Society Type', value: 'Integrated Multi-Purpose CS' },
          { label: 'Loan Interest Rate', value: '10% per annum' },
          { label: 'NSCU Membership', value: '₹100/year' },
          { label: 'Share Value', value: '6 shares × ₹400 = ₹2,400' },
          { label: 'Grand Total (Day Book)', value: '₹6,34,375' },
          { label: 'Closing Balance', value: '₹14,103' },
        ].map(item => (
          <div key={item.label}>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 2 }}>{item.label}</div>
            <div className="amount" style={{ fontSize: 14, fontWeight: 600, color: '#e6edf3' }}>{item.value}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
