import { useState } from 'react'
import { downloadCSV } from '../utils/downloadCSV'

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2 }).format(n)

/* ── Stock Ledger data (from image) ─────────────────────────── */
type StockItem = { slno: number; particulars: string; quantity: string; rate: string; amount: number }

const initialStock: StockItem[] = [
  { slno: 1, particulars: 'Chicken', quantity: '15 Nos. × 2 Kgs each', rate: '₹280 per kg.', amount: 8400 },
  { slno: 2, particulars: 'Feeds',   quantity: '35 Kgs.',              rate: '₹50 per kg.',  amount: 1750 },
]

/* ── Investment Register data ───────────────────────────────── */
type Investment = { slno: number; projectName: string; quantity: string; rate: string; amount: number }

const initialInvestments: Investment[] = [
  { slno: 1, projectName: 'Construction of Pigsty',        quantity: '1 unit',            rate: '₹40,800 lump sum', amount: 40800 },
  { slno: 2, projectName: 'Construction of Poultry Shed',  quantity: '1 unit',            rate: '₹30,000 lump sum', amount: 30000 },
  { slno: 3, projectName: 'Purchase of Piglets',           quantity: '10 nos.',           rate: '₹8,000 each',      amount: 80000 },
  { slno: 4, projectName: 'Broiler Chicks (Batch 1)',      quantity: '50 nos.',           rate: '₹160 each',        amount: 8000  },
  { slno: 5, projectName: 'Broiler Chicks (Batch 2)',      quantity: '20 nos.',           rate: '₹160 each',        amount: 3200  },
  { slno: 6, projectName: 'Broiler Chicks (Batch 3)',      quantity: '50 nos.',           rate: '₹160 each',        amount: 8000  },
  { slno: 7, projectName: 'Pig Feed Stock',                quantity: '17 bags',           rate: '₹1,500 per bag',   amount: 25500 },
  { slno: 8, projectName: 'Broiler Feed Stock',            quantity: '6 bags',            rate: '₹2,700 per bag',   amount: 16200 },
  { slno: 9, projectName: 'Labour & Construction Work',    quantity: '500 × 3 × 12 days', rate: '₹500 per labour',  amount: 18000 },
  { slno: 10, projectName: 'Packaging Materials',          quantity: '1 lot',             rate: 'market rate',      amount: 2000  },
]

/* ── Blank row shape ─────────────────────────────────────────── */
const blankStock  = (): StockItem    => ({ slno: 0, particulars: '', quantity: '', rate: '', amount: 0 })
const blankInvest = (): Investment   => ({ slno: 0, projectName: '', quantity: '', rate: '', amount: 0 })

/* ── Shared table wrapper ────────────────────────────────────── */
function TableCard({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden' }}>
      <div style={{ padding: '14px 20px', borderBottom: '1px solid #30363d', display: 'flex', alignItems: 'baseline', gap: 10 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: '#e6edf3' }}>{title}</span>
        <span style={{ fontSize: 12, color: '#8b949e' }}>{subtitle}</span>
      </div>
      <div className="table-wrap">{children}</div>
    </div>
  )
}

/* ══════════════════════════════════════════════════════════════ */
export default function StockRegister() {
  const [tab, setTab]                   = useState<'stock' | 'investment'>('stock')

  /* stock state */
  const [stockItems, setStockItems]     = useState<StockItem[]>(initialStock)
  const [addingStock, setAddingStock]   = useState(false)
  const [draftStock, setDraftStock]     = useState<StockItem>(blankStock())

  /* investment state */
  const [investments, setInvestments]   = useState<Investment[]>(initialInvestments)
  const [addingInv, setAddingInv]       = useState(false)
  const [draftInv, setDraftInv]         = useState<Investment>(blankInvest())

  /* ── helpers ── */
  const saveStock = () => {
    if (!draftStock.particulars) return
    setStockItems(prev => [...prev, { ...draftStock, slno: prev.length + 1 }])
    setDraftStock(blankStock())
    setAddingStock(false)
  }

  const saveInv = () => {
    if (!draftInv.projectName) return
    setInvestments(prev => [...prev, { ...draftInv, slno: prev.length + 1 }])
    setDraftInv(blankInvest())
    setAddingInv(false)
  }

  const stockTotal = stockItems.reduce((s, r) => s + r.amount, 0)
  const invTotal   = investments.reduce((s, r) => s + r.amount, 0)

  /* ── sub-tab bar ── */
  const SubTab = ({ id, label }: { id: 'stock' | 'investment'; label: string }) => (
    <button onClick={() => setTab(id)} style={{
      background: tab === id ? '#1a8cff' : 'transparent',
      color:      tab === id ? 'white'   : '#8b949e',
      fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13,
      borderTop: 'none', borderLeft: 'none', borderRight: 'none',
      borderBottom: 'none',
      borderRadius: 7, padding: '7px 20px',
      cursor: 'pointer', transition: 'all 0.15s',
    }}>{label}</button>
  )

  /* ── inline add-row form ── */
  function AddRowForm({ fields, onSave, onCancel }: {
    fields: { label: string; key: string; type?: string }[]
    onSave: () => void
    onCancel: () => void
  }) {
    return (
      <tr style={{ background: '#1a8cff0d' }}>
        {fields.map(f => (
          <td key={f.key} style={{ padding: '8px 14px' }}>
            <input
              type={f.type || 'text'}
              placeholder={f.label}
              style={{ width: '100%', minWidth: 80 }}
              value={
                tab === 'stock'
                  ? String((draftStock as Record<string,unknown>)[f.key] ?? '')
                  : String((draftInv   as Record<string,unknown>)[f.key] ?? '')
              }
              onChange={e => {
                const val = f.type === 'number' ? +e.target.value : e.target.value
                tab === 'stock'
                  ? setDraftStock(d => ({ ...d, [f.key]: val }))
                  : setDraftInv(d  => ({ ...d, [f.key]: val }))
              }}
            />
          </td>
        ))}
        <td style={{ padding: '8px 14px' }}>
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="btn-primary" style={{ padding: '4px 12px', fontSize: 12 }} onClick={onSave}>Save</button>
            <button className="btn-ghost"   style={{ padding: '4px 10px', fontSize: 12 }} onClick={onCancel}>✕</button>
          </div>
        </td>
      </tr>
    )
  }

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 20 }}>

      {/* Page header */}
      <div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, color: '#e6edf3', margin: 0 }}>
          Stock &amp; Investment Register
        </h1>
        <p style={{ color: '#8b949e', fontSize: 13, margin: '4px 0 0' }}>
          XX IMPCS Ltd. · Sample Stock Register &amp; Project Investment Ledger
        </p>
      </div>

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
        {[
          { label: 'Stock Value',        value: stockTotal, color: '#00d4aa' },
          { label: 'Total Investment',   value: invTotal,   color: '#1a8cff' },
          { label: 'Combined Portfolio', value: stockTotal + invTotal, color: '#a78bfa' },
        ].map(c => (
          <div key={c.label} style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 10, padding: '16px 20px' }}>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>{c.label}</div>
            <div className="amount" style={{ fontSize: 22, fontWeight: 700, color: c.color }}>{fmt(c.value)}</div>
          </div>
        ))}
      </div>

      {/* Sub-tab switcher */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
        <div style={{ display: 'flex', background: '#161b22', border: '1px solid #30363d', borderRadius: 10, padding: 4, gap: 2 }}>
          <SubTab id="stock"      label="Stock Ledger" />
          <SubTab id="investment" label="Investment Register" />
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-ghost" style={{ fontSize: 12 }} onClick={() => {
            if (tab === 'stock') {
              downloadCSV('impcs-stock-ledger.csv',
                ['Sl.No','Particulars','Quantity','Rate','Amount (₹)'],
                [stockItems.map(r => [r.slno, r.particulars, r.quantity, r.rate, r.amount])])
            } else {
              downloadCSV('impcs-investment-register.csv',
                ['Sl.No','Name of the Project','Quantity','Rate','Amount (₹)'],
                [investments.map(r => [r.slno, r.projectName, r.quantity, r.rate, r.amount])])
            }
          }}>⬇ CSV</button>
          <button className="btn-primary" onClick={() => tab === 'stock' ? setAddingStock(true) : setAddingInv(true)}>
            + Add Entry
          </button>
        </div>
      </div>

      {/* ── STOCK LEDGER ── */}
      {tab === 'stock' && (
        <TableCard title="Stock Ledger" subtitle="Sample Stock Register in Respect of XX IMPCS Ltd.">
          <table>
            <thead>
              <tr>
                <th style={{ width: 60 }}>Sl.No</th>
                <th>Particulars</th>
                <th>Quantity</th>
                <th>Rate</th>
                <th style={{ textAlign: 'right' }}>Amount</th>
              </tr>
            </thead>
            <tbody>
              {stockItems.map(r => (
                <tr key={r.slno}>
                  <td className="amount" style={{ color: '#8b949e' }}>{r.slno}</td>
                  <td style={{ fontWeight: 600 }}>{r.particulars}</td>
                  <td style={{ color: '#8b949e' }}>{r.quantity}</td>
                  <td style={{ color: '#8b949e' }}>{r.rate}</td>
                  <td className="amount" style={{ textAlign: 'right', fontWeight: 600, color: '#00d4aa' }}>{fmt(r.amount)}</td>
                </tr>
              ))}
              {addingStock && (
                <AddRowForm
                  fields={[
                    { label: 'Particulars', key: 'particulars' },
                    { label: 'Quantity',    key: 'quantity' },
                    { label: 'Rate',        key: 'rate' },
                    { label: 'Amount',      key: 'amount', type: 'number' },
                  ]}
                  onSave={saveStock}
                  onCancel={() => setAddingStock(false)}
                />
              )}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={4} style={{ color: '#8b949e' }}>Total</td>
                <td className="amount" style={{ textAlign: 'right', color: '#00d4aa' }}>{fmt(stockTotal)}</td>
              </tr>
            </tfoot>
          </table>
        </TableCard>
      )}

      {/* ── INVESTMENT REGISTER ── */}
      {tab === 'investment' && (
        <TableCard title="Investment Register" subtitle="Project-wise capital deployment · XX IMPCS Ltd.">
          <table>
            <thead>
              <tr>
                <th style={{ width: 60 }}>Sl.No</th>
                <th>Name of the Project</th>
                <th>Quantity</th>
                <th>Rate</th>
                <th style={{ textAlign: 'right' }}>Amount</th>
              </tr>
            </thead>
            <tbody>
              {investments.map(r => (
                <tr key={r.slno}>
                  <td className="amount" style={{ color: '#8b949e' }}>{r.slno}</td>
                  <td style={{ fontWeight: 600 }}>{r.projectName}</td>
                  <td style={{ color: '#8b949e' }}>{r.quantity}</td>
                  <td style={{ color: '#8b949e' }}>{r.rate}</td>
                  <td className="amount" style={{ textAlign: 'right', fontWeight: 600, color: '#1a8cff' }}>{fmt(r.amount)}</td>
                </tr>
              ))}
              {addingInv && (
                <AddRowForm
                  fields={[
                    { label: 'Name of the Project', key: 'projectName' },
                    { label: 'Quantity',            key: 'quantity' },
                    { label: 'Rate',                key: 'rate' },
                    { label: 'Amount',              key: 'amount', type: 'number' },
                  ]}
                  onSave={saveInv}
                  onCancel={() => setAddingInv(false)}
                />
              )}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={4} style={{ color: '#8b949e' }}>Total Investment</td>
                <td className="amount" style={{ textAlign: 'right', color: '#1a8cff' }}>{fmt(invTotal)}</td>
              </tr>
            </tfoot>
          </table>
        </TableCard>
      )}

    </div>
  )
}
