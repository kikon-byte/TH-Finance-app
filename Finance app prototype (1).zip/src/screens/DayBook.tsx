import { useState } from 'react'
import { downloadCSV } from '../utils/downloadCSV'
import { useRegisters } from '../context/RegistersContext'

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

type Entry = { slno: number; date: string; month: string; particulars: string; receipt: number | null; payment: number | null; source?: 'manual' | 'project' }

const allEntries: Entry[] = [
  { slno: 1, date: '01/04/2024', month: 'April', particulars: 'Opening Balance', receipt: 15134, payment: null },
  { slno: 2, date: '04/04/2024', month: 'April', particulars: 'Interest received from member', receipt: 10000, payment: null },
  { slno: 3, date: '04/04/2024', month: 'April', particulars: 'Loan received from member', receipt: 100000, payment: null },
  { slno: 4, date: '04/04/2024', month: 'April', particulars: 'Printing & Stationery', receipt: null, payment: 2100 },
  { slno: 5, date: '05/04/2024', month: 'April', particulars: 'Temporary loan from members', receipt: 120000, payment: null },
  { slno: 6, date: '05/04/2024', month: 'April', particulars: 'Meeting expenses', receipt: null, payment: 3000 },
  { slno: 7, date: '06/04/2024', month: 'April', particulars: 'Construction of Pigsty', receipt: null, payment: 40800 },
  { slno: 8, date: '06/04/2024', month: 'April', particulars: 'Carriage Charge', receipt: null, payment: 5000 },
  { slno: 9, date: '08/04/2024', month: 'April', particulars: 'Salary to 2 attendants', receipt: null, payment: 7000 },
  { slno: 10, date: '14/04/2024', month: 'April', particulars: 'Electricity Bill for March', receipt: null, payment: 300 },
  { slno: 11, date: '13/04/2024', month: 'April', particulars: 'Construction of poultry shed', receipt: null, payment: 30000 },
  { slno: 12, date: '13/04/2024', month: 'April', particulars: 'Carriage charge', receipt: null, payment: 5000 },
  { slno: 13, date: '20/04/2024', month: 'April', particulars: 'Labour Charge (500 × 3 labours × 12 days)', receipt: null, payment: 18000 },
  { slno: 14, date: '23/04/2024', month: 'April', particulars: 'Purchase of Pig feeds 10 bags × 1500', receipt: null, payment: 15000 },
  { slno: 15, date: '23/04/2024', month: 'April', particulars: 'Purchase of Piglet 10 nos × 8000', receipt: null, payment: 70000 },
  { slno: 16, date: '23/04/2024', month: 'April', particulars: 'Carriage charge', receipt: null, payment: 5500 },
  { slno: 17, date: '23/04/2024', month: 'April', particulars: 'Travelling expenses', receipt: null, payment: 2500 },
  { slno: 18, date: '08/05/2024', month: 'May', particulars: 'Salary to 2 attendants', receipt: null, payment: 7000 },
  { slno: 19, date: '09/05/2024', month: 'May', particulars: 'Purchase of Broiler chicks 50 × 160', receipt: null, payment: 8000 },
  { slno: 20, date: '09/05/2024', month: 'May', particulars: 'Purchase of Broiler Feeds 2 bags × 2700', receipt: null, payment: 5400 },
  { slno: 21, date: '09/05/2024', month: 'May', particulars: 'Carriage charge', receipt: null, payment: 500 },
  { slno: 22, date: '09/05/2024', month: 'May', particulars: 'Electricity Bill for April', receipt: null, payment: 300 },
  { slno: 23, date: '08/06/2024', month: 'June', particulars: 'Purchase of Broiler chicks 20 × 160', receipt: null, payment: 3200 },
  { slno: 24, date: '08/06/2024', month: 'June', particulars: 'Salary to 2 attendants', receipt: null, payment: 7000 },
  { slno: 25, date: '09/06/2024', month: 'June', particulars: 'Purchase of Pig feeds 3 bags × 1500', receipt: null, payment: 4500 },
  { slno: 26, date: '09/06/2024', month: 'June', particulars: 'Carriage charge', receipt: null, payment: 500 },
  { slno: 27, date: '09/06/2024', month: 'June', particulars: 'Labour charge', receipt: null, payment: 300 },
  { slno: 28, date: '10/06/2024', month: 'June', particulars: 'Purchase of Medicine', receipt: null, payment: 3000 },
  { slno: 29, date: '14/06/2024', month: 'June', particulars: 'Electricity Bill for May', receipt: null, payment: 300 },
  { slno: 30, date: '19/06/2024', month: 'June', particulars: 'Purchase of packaging materials', receipt: 28000, payment: null },
  { slno: 31, date: '19/06/2024', month: 'June', particulars: 'Sale of Broiler 50 nos × 2kg @ ₹280', receipt: 28000, payment: null },
  { slno: 32, date: '08/07/2024', month: 'July', particulars: 'Salary to 2 attendants', receipt: null, payment: 7000 },
  { slno: 33, date: '09/07/2024', month: 'July', particulars: 'Purchase of Pig feeds 4 bags × 1500', receipt: null, payment: 6000 },
  { slno: 34, date: '09/07/2024', month: 'July', particulars: 'Carriage charge', receipt: null, payment: 500 },
  { slno: 35, date: '09/07/2024', month: 'July', particulars: 'Labour charge', receipt: null, payment: 300 },
  { slno: 36, date: '10/07/2024', month: 'July', particulars: 'Meeting Expenses', receipt: null, payment: 2000 },
  { slno: 37, date: '10/07/2024', month: 'July', particulars: 'Honorarium to Chairman', receipt: null, payment: 11000 },
  { slno: 38, date: '14/07/2024', month: 'July', particulars: 'Electricity Bill for June', receipt: null, payment: 300 },
  { slno: 39, date: '19/07/2024', month: 'July', particulars: 'Sale of Broiler 20 nos × 3kg @ ₹280', receipt: 16800, payment: null },
  { slno: 40, date: '19/07/2024', month: 'July', particulars: 'Misc. expenses', receipt: null, payment: 905 },
  { slno: 41, date: '08/08/2024', month: 'August', particulars: 'Salary to 2 attendants', receipt: null, payment: 7000 },
  { slno: 42, date: '09/08/2024', month: 'August', particulars: 'Purchase of Pig feeds 3 bags × 1500', receipt: null, payment: 4500 },
  { slno: 43, date: '09/08/2024', month: 'August', particulars: 'Carriage charge', receipt: null, payment: 500 },
  { slno: 44, date: '09/08/2024', month: 'August', particulars: 'Labour charge', receipt: null, payment: 300 },
  { slno: 45, date: '10/08/2024', month: 'August', particulars: 'Purchase of Broiler chicks 50 @ 160/chicks', receipt: null, payment: 8000 },
  { slno: 46, date: '10/08/2024', month: 'August', particulars: 'Purchase of Broiler Feeds 2 bag × 2700', receipt: null, payment: 5400 },
  { slno: 47, date: '14/08/2024', month: 'August', particulars: 'Electricity Bill for July', receipt: null, payment: 300 },
  { slno: 48, date: '27/08/2024', month: 'August', particulars: 'Bank interest received', receipt: 85, payment: null },
  // March 2025
  { slno: 99, date: '03/08/2025', month: 'March 2025', particulars: 'Salary to 2 attendants', receipt: null, payment: 7000 },
  { slno: 100, date: '03/09/2025', month: 'March 2025', particulars: 'Purchase of Pig feeds 3 bags × 1500', receipt: null, payment: 4500 },
  { slno: 101, date: '03/09/2025', month: 'March 2025', particulars: 'Carriage charge', receipt: null, payment: 500 },
  { slno: 102, date: '03/09/2025', month: 'March 2025', particulars: 'Labour charge', receipt: null, payment: 500 },
  { slno: 103, date: '03/10/2025', month: 'March 2025', particulars: 'Sale of Pig 2 nos × 90kg @ ₹300/kg', receipt: 54000, payment: null },
  { slno: 104, date: '03/11/2025', month: 'March 2025', particulars: 'Purchase of broiler feeds 1 bag × 2700', receipt: null, payment: 2700 },
  { slno: 105, date: '03/14/2025', month: 'March 2025', particulars: 'Electricity Bill for February', receipt: null, payment: 300 },
  { slno: 106, date: '03/25/2025', month: 'March 2025', particulars: 'Travelling expenses', receipt: null, payment: 3245 },
  { slno: 107, date: '03/25/2025', month: 'March 2025', particulars: 'Temporary loan refunded', receipt: null, payment: 120000 },
  { slno: 108, date: '03/25/2025', month: 'March 2025', particulars: 'Meeting Expense', receipt: null, payment: 2000 },
  { slno: 109, date: '03/25/2025', month: 'March 2025', particulars: 'Honorarium to Chairman', receipt: null, payment: 11000 },
  { slno: 110, date: '03/25/2025', month: 'March 2025', particulars: 'Misc. expenses', receipt: null, payment: 1268 },
  { slno: 111, date: '03/25/2025', month: 'March 2025', particulars: 'Printing & stationery', receipt: null, payment: 2200 },
  { slno: 112, date: '03/25/2025', month: 'March 2025', particulars: 'Audit (₹300) & NSCU (₹100) Fee', receipt: null, payment: 400 },
  { slno: 113, date: '31/03/2025', month: 'March 2025', particulars: 'Audit (₹300) & NSCU (₹100) Fee', receipt: null, payment: 400 },
]

const months = ['All', ...Array.from(new Set(allEntries.map(e => e.month)))]

export default function DayBook() {
  const { projectEntries } = useRegisters()
  const [monthFilter, setMonthFilter] = useState('All')
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [newEntry, setNewEntry] = useState({ date: '', particulars: '', receipt: '', payment: '' })
  const [entries, setEntries] = useState(allEntries)

  // Merge project entries into day book view
  const projectAsDayBook: Entry[] = projectEntries.map(p => ({
    slno: 0,
    date: p.date,
    month: (() => {
      const parts = p.date.split('/')
      if (parts.length < 2) return 'Unknown'
      const d = new Date(+parts[2], +parts[1] - 1, +parts[0])
      return isNaN(d.getTime()) ? 'Unknown' : d.toLocaleString('en-IN', { month: 'long' })
    })(),
    particulars: p.projectName,
    receipt: p.receipt,
    payment: p.payment,
    source: 'project',
  }))

  const allCombined = [...entries, ...projectAsDayBook]

  const filtered = allCombined.filter(e => {
    if (monthFilter !== 'All' && e.month !== monthFilter) return false
    if (search && !e.particulars.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const totalReceipt = filtered.reduce((s, e) => s + (e.receipt || 0), 0)
  const totalPayment = filtered.reduce((s, e) => s + (e.payment || 0), 0)

  const addEntry = () => {
    const next: Entry = {
      slno: entries.length + 1,
      date: newEntry.date,
      month: new Date(newEntry.date).toLocaleString('en-IN', { month: 'long' }),
      particulars: newEntry.particulars,
      receipt: newEntry.receipt ? +newEntry.receipt : null,
      payment: newEntry.payment ? +newEntry.payment : null,
    }
    setEntries([...entries, next])
    setNewEntry({ date: '', particulars: '', receipt: '', payment: '' })
    setShowAdd(false)
  }

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, color: '#e6edf3', margin: 0 }}>
          Day Book Register
        </h1>
        <p style={{ color: '#8b949e', fontSize: 13, margin: '4px 0 0' }}>
          Daily Recorded Financial Expenses · XX IMPCS Ltd. · XX Village
        </p>
      </div>

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {[
          { label: 'Total Receipts', value: totalReceipt, color: '#3fb950' },
          { label: 'Total Payments', value: totalPayment, color: '#f85149' },
          { label: 'Net Balance', value: totalReceipt - totalPayment, color: totalReceipt - totalPayment >= 0 ? '#00d4aa' : '#f85149' },
        ].map(c => (
          <div key={c.label} style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 10, padding: '14px 18px' }}>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>{c.label}</div>
            <div className="amount" style={{ fontSize: 22, fontWeight: 700, color: c.color }}>{fmt(c.value)}</div>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
        <input
          placeholder="Search transactions..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ width: 220 }}
        />
        <select value={monthFilter} onChange={e => setMonthFilter(e.target.value)} style={{ width: 160 }}>
          {months.map(m => <option key={m}>{m}</option>)}
        </select>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
          <button className="btn-ghost" style={{ fontSize: 12 }} onClick={() =>
            downloadCSV(
              'impcs-daybook.csv',
              ['Sl.No', 'Date', 'Month', 'Particulars', 'Receipt (₹)', 'Payment (₹)'],
              [filtered.map(e => [e.slno, e.date, e.month, e.particulars, e.receipt ?? '', e.payment ?? ''])],
            )
          }>⬇ CSV</button>
          <button className="btn-primary" onClick={() => setShowAdd(!showAdd)}>
            + Add Entry
          </button>
        </div>
      </div>

      {/* Add entry form */}
      {showAdd && (
        <div style={{ background: '#161b22', border: '1px solid #1a8cff44', borderRadius: 12, padding: 18, display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>Date</div>
            <input type="date" value={newEntry.date} onChange={e => setNewEntry({ ...newEntry, date: e.target.value })} style={{ width: 140 }} />
          </div>
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>Particulars</div>
            <input placeholder="Enter description..." value={newEntry.particulars} onChange={e => setNewEntry({ ...newEntry, particulars: e.target.value })} style={{ width: '100%' }} />
          </div>
          <div>
            <div style={{ fontSize: 11, color: '#3fb950', marginBottom: 4 }}>Receipt (₹)</div>
            <input type="number" placeholder="0" value={newEntry.receipt} onChange={e => setNewEntry({ ...newEntry, receipt: e.target.value })} style={{ width: 120 }} />
          </div>
          <div>
            <div style={{ fontSize: 11, color: '#f85149', marginBottom: 4 }}>Payment (₹)</div>
            <input type="number" placeholder="0" value={newEntry.payment} onChange={e => setNewEntry({ ...newEntry, payment: e.target.value })} style={{ width: 120 }} />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-primary" onClick={addEntry}>Save</button>
            <button className="btn-ghost" onClick={() => setShowAdd(false)}>Cancel</button>
          </div>
        </div>
      )}

      {/* Table */}
      <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 12, overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid #30363d', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, color: '#e6edf3' }}>
            {filtered.length} entries {monthFilter !== 'All' ? `· ${monthFilter}` : ''}
          </span>
          <span style={{ fontSize: 12, color: '#8b949e' }}>Grand Total: {fmt(634375)}</span>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th style={{ width: 60 }}>Sl.No</th>
                <th>Date</th>
                <th>Month</th>
                <th>Particulars</th>
                <th style={{ textAlign: 'right' }}>Receipt (₹)</th>
                <th style={{ textAlign: 'right' }}>Payment (₹)</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((e, i) => (
                <tr key={i} className="row-hover">
                  <td className="amount" style={{ color: '#8b949e', fontSize: 12 }}>{e.slno}</td>
                  <td className="amount" style={{ fontSize: 12, color: '#8b949e' }}>{e.date}</td>
                  <td>
                    <span style={{ background: '#1c2330', border: '1px solid #30363d', borderRadius: 4, padding: '2px 8px', fontSize: 11, color: '#8b949e' }}>
                      {e.month}
                    </span>
                  </td>
                  <td style={{ maxWidth: 320 }}>
                    <span>{e.particulars}</span>
                    {e.source === 'project' && (
                      <span style={{ marginLeft: 8, background: '#00d4aa18', color: '#00d4aa', border: '1px solid #00d4aa44', borderRadius: 3, padding: '1px 6px', fontSize: 10, fontWeight: 700, fontFamily: 'var(--font-display)' }}>Project</span>
                    )}
                  </td>
                  <td className="amount" style={{ textAlign: 'right', color: '#3fb950', fontWeight: e.receipt ? 600 : 400 }}>
                    {e.receipt ? fmt(e.receipt) : <span style={{ color: '#30363d' }}>—</span>}
                  </td>
                  <td className="amount" style={{ textAlign: 'right', color: '#f85149', fontWeight: e.payment ? 600 : 400 }}>
                    {e.payment ? fmt(e.payment) : <span style={{ color: '#30363d' }}>—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={4} style={{ color: '#8b949e' }}>Total (filtered)</td>
                <td className="amount" style={{ textAlign: 'right', color: '#3fb950' }}>{fmt(totalReceipt)}</td>
                <td className="amount" style={{ textAlign: 'right', color: '#f85149' }}>{fmt(totalPayment)}</td>
              </tr>
              <tr>
                <td colSpan={4} style={{ color: '#8b949e' }}>Closing Balance</td>
                <td className="amount" colSpan={2} style={{ textAlign: 'right', color: '#00d4aa' }}>₹14,103</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  )
}
