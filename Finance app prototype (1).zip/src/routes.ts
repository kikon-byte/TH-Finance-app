import { createBrowserRouter } from 'react-router'
import Layout from './components/Layout'
import Landing from './screens/Landing'
import Dashboard from './screens/Dashboard'
import DayBook from './screens/DayBook'
import LoanRegister from './screens/LoanRegister'
import ShareLedger from './screens/ShareLedger'
import StockRegister from './screens/StockRegister'
import AssetRegister from './screens/AssetRegister'
import ProjectRegister from './screens/ProjectRegister'
import MembershipRegister from './screens/MembershipRegister'

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true,         Component: Landing },
      { path: 'dashboard',   Component: Dashboard },
      { path: 'daybook',     Component: DayBook },
      { path: 'loans',       Component: LoanRegister },
      { path: 'shares',      Component: ShareLedger },
      { path: 'stock',       Component: StockRegister },
      { path: 'assets',      Component: AssetRegister },
      { path: 'projects',    Component: ProjectRegister },
      { path: 'members',     Component: MembershipRegister },
    ],
  },
])
