import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import { RegistersProvider } from './context/RegistersContext'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RegistersProvider>
      <App />
    </RegistersProvider>
  </React.StrictMode>,
)
