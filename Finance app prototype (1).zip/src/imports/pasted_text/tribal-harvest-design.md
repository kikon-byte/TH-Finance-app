Design and prototype a complete responsive web application called:

TRIBAL HARVEST
Cooperative Management & Accounting System

Tagline:
"One Transaction. Every Register. Automatically Synced."

PURPOSE
Create a practical accounting and cooperative-management application for Tribal Harvest Marketing Cooperative Society Ltd.

The application replaces physical registers with a connected digital system.

The most important design principle is:

ENTER DATA ONCE → AUTOMATICALLY UPDATE ALL RELEVANT REGISTERS, LEDGERS, REPORTS AND FINANCIAL STATEMENTS.

The system must be designed for non-technical cooperative staff who are familiar with physical registers, cash books, loan registers, share registers, stock registers and handwritten accounting.

The interface should therefore be simple, familiar, clean and highly practical.

--------------------------------------------------
1. DESIGN LANGUAGE
--------------------------------------------------

Create a professional but community-oriented visual identity.

Brand:
TRIBAL HARVEST

Visual character:
- Modern cooperative
- Trustworthy
- Agricultural
- Naga cultural influence
- Professional accounting software
- Simple enough for ordinary staff

Use:
- Deep Naga-inspired red as the primary accent
- Warm cream/off-white background
- Dark charcoal text
- Subtle green accents for agriculture/business
- White cards
- Rounded corners
- Clear tables
- Strong typography
- Minimal decorative elements

Do NOT make the interface look like a generic banking app.

Use subtle Naga-inspired patterns only in headers, login screen or empty-state illustrations. Keep the accounting interface clean.

Desktop-first responsive web application.

Also design mobile-responsive versions for important screens.

--------------------------------------------------
2. MAIN NAVIGATION
--------------------------------------------------

Create a permanent left sidebar on desktop.

Navigation:

Dashboard

TRANSACTIONS
- New Transaction
- Receive Money
- Make Payment
- Transfer
- Loan Disbursement
- Loan Repayment
- Share Contribution
- Purchase
- Sale
- Stock Adjustment

COOPERATIVE
- Members
- Membership Register
- Share Ledger
- Member Ledger

LOANS
- Loan Register
- Loan Disbursement
- Loan Repayment
- Outstanding Loans
- Interest

BUSINESS
- Authentic Naga Food
- Bastenga
- Penjung Han
- Machi Han
- Farm Harvest
- Cloud Kitchen
- First Pick
- Other Activities

INVENTORY
- Stock Register
- Purchases
- Sales
- Suppliers

FINANCE
- Cash Book / Day Book
- Bank Book
- Bank Reconciliation
- General Ledger
- Trial Balance
- Income & Expenditure
- Balance Sheet

ASSETS & INVESTMENTS
- Fixed Assets
- Asset Register
- Depreciation
- Investments
- Investment Register

REPORTS
- Daily Reports
- Monthly Reports
- Annual Reports
- Cooperative Reports
- Audit Reports
- Export Excel
- Export PDF

ADMINISTRATION
- Users & Roles
- Audit Trail
- Settings

--------------------------------------------------
3. LOGIN SCREEN
--------------------------------------------------

Create a professional login page.

Logo:
TRIBAL HARVEST

Subtitle:
Cooperative Management & Accounting System

Fields:
Email / Mobile
Password

Buttons:
Sign In

Below:
"Secure financial records for Tribal Harvest"

Show subtle agricultural/Naga-inspired background pattern.

--------------------------------------------------
4. DASHBOARD
--------------------------------------------------

Create a highly useful financial dashboard.

Header:

Good Morning

TRIBAL HARVEST
Financial Year 2026–27

Date selector.

Top cards:

Cash Balance
₹XX,XXX

Bank Balance
₹XX,XXX

Total Receivables
₹XX,XXX

Total Payables
₹XX,XXX

Investments
₹XX,XXX

Fixed Assets
₹XX,XXX

Stock Value
₹XX,XXX

Share Capital
₹XX,XXX

Below:

TODAY'S ACTIVITY

Receipts
₹XX,XXX

Payments
₹XX,XXX

Net Movement
₹XX,XXX

Then:

BUSINESS PERFORMANCE

Show cards or table:

Authentic Naga Food
Revenue
Expenses
Surplus

Bastenga
Revenue
Expenses
Surplus

Farm Harvest
Revenue
Expenses
Surplus

Other Activities

Then:

RECENT TRANSACTIONS

Columns:
Date
Transaction ID
Particulars
Business Unit
Receipt
Payment
Balance

Then:

QUICK ACTIONS

+ Receive Money
+ Make Payment
+ New Catering Event
+ Loan Disbursement
+ Loan Repayment
+ Purchase
+ Sale
+ Add Asset

--------------------------------------------------
5. CORE PRINCIPLE: ONE TRANSACTION → MULTIPLE REGISTERS
--------------------------------------------------

Demonstrate this visually in the prototype.

For example:

A user records a loan disbursement:

Member:
John
Amount:
₹10,000
Interest:
10% p.a.
Mode:
Cash

After saving, show:

✓ Cash Book updated
✓ Loan Register updated
✓ Member Ledger updated
✓ General Ledger updated
✓ Dashboard updated

Create a small "Automatically Synced" confirmation panel.

Use the concept:

ONE ENTRY
↓
CASH/BANK
↓
REGISTER
↓
LEDGER
↓
REPORT
↓
FINANCIAL STATEMENTS

--------------------------------------------------
6. NEW TRANSACTION
--------------------------------------------------

Create a universal transaction screen.

Fields:

Transaction Type
Date
Transaction ID
Business Unit
Account
Particulars
Amount
Payment/Receipt Mode
Cash / Bank
Member
Supplier
Customer
Reference Number
Notes
Attachment

Buttons:

Save Transaction
Save & New
Cancel

Show a right-side accounting preview:

ACCOUNTING EFFECT

Debit:
XXXXX ₹XX,XXX

Credit:
XXXXX ₹XX,XXX

This should help staff understand what the system is recording.

--------------------------------------------------
7. DAILY CASH BOOK / DAY BOOK
--------------------------------------------------

Design the digital equivalent of the physical Day Book shown in the reference register.

Title:

DAILY CASH BOOK

Filters:
Financial Year
From Date
To Date
Business Unit
Transaction Type

Table:

Sl. No.
Date
Transaction ID
Particulars
Receipt
Payment
Balance

Example transactions:

Opening Balance
Interest Received
Loan Received
Loan Given
Printing & Stationery
Meeting Expenses
Salary
Electricity
Carriage
Labour
Purchase
Sale
Travelling Expenses

At bottom:

Total Receipts
Total Payments
Closing Balance

Buttons:

Export Excel
Export PDF
Print

Make this screen visually resemble a modern digital version of the physical register.

--------------------------------------------------
8. BANK BOOK & BRS
--------------------------------------------------

Bank Book table:

Date
Particulars
Deposit
Withdrawal
Balance
Reference

Bank Reconciliation screen:

Book Balance
Bank Statement Balance
Deposits in Transit
Unpresented Cheques
Bank Charges
Interest
Other Adjustments
Adjusted Balance

Show:

RECONCILIATION STATUS

✓ Reconciled

or

⚠ Difference: ₹XXX

Allow:

Import Bank Statement
Match Transactions
Mark Reconciled
Add Adjustment

--------------------------------------------------
9. MEMBERSHIP REGISTER
--------------------------------------------------

Create:

MEMBERSHIP REGISTER

Columns:

Member ID
Name
Father/Spouse Name
Address
Phone
Aadhaar/ID Reference
Date of Admission
Membership Fee
Share Capital
Number of Shares
Status

Status:
Active
Inactive
Resigned
Membership Revoked

Member profile page:

Member ID
Personal information
Membership history
Shares
Loans
Repayments
Transactions
Documents

--------------------------------------------------
10. SHARE LEDGER
--------------------------------------------------

Create a digital version of the physical Share Ledger shown in the reference image.

Columns:

Sl. No.
Member Name
Member ID
Date
No. of Shares
Value per Share
Amount of Share Paid
Amount Withdrawn
Balance

Summary:

Total Members
Total Shares
Total Share Capital

Include:

Add Share Contribution
Share Withdrawal
Transfer
Print Ledger
Export Excel

Any share contribution must automatically update:

Cash/Bank
Share Ledger
Member Ledger
General Ledger
Balance Sheet → Share Capital

--------------------------------------------------
11. LOAN MANAGEMENT
--------------------------------------------------

Create Loan Register.

Columns:

Loan ID
Member
Date
Amount Disbursed
Interest Rate
Purpose
Due Date
Principal Repaid
Interest Repaid
Outstanding Principal
Outstanding Interest
Status

Loan detail screen:

Member
Loan Amount
Interest Rate
Disbursement Date
Repayment Schedule
Principal Outstanding
Interest Outstanding
Total Outstanding

Buttons:

Disburse Loan
Record Repayment
Print Statement

When loan is disbursed:

Cash/Bank decreases
Loan Receivable increases
Loan Register updates
Member Ledger updates

When repayment occurs:

Cash/Bank increases
Principal decreases
Interest Income increases
Loan Register updates
Member Ledger updates

--------------------------------------------------
12. AUTHENTIC NAGA FOOD
--------------------------------------------------

Create a dedicated business module.

Title:

AUTHENTIC NAGA FOOD

Subtitle:

Catering & Food Business Management

Dashboard cards:

Upcoming Events
Today's Events
Monthly Revenue
Monthly Expenses
Monthly Surplus
Total Plates Served

Main button:

+ New Catering Event

--------------------------------------------------
13. NEW CATERING EVENT
--------------------------------------------------

Create an event-based form.

Fields:

Event ID
Date
Customer Name
Customer Phone
Event / Function
Venue
Number of Plates
Price per Plate
Total Revenue
Payment Status
Advance Received
Balance Due

Automatically calculate:

Total Revenue =
Number of Plates × Price per Plate

Example:

Customer:
ABC Association

Date:
25 September 2026

Plates:
150

Price:
₹300

Total:
₹45,000

Payment:
Advance ₹20,000
Balance ₹25,000

--------------------------------------------------
14. CATERING COST SHEET
--------------------------------------------------

Every catering event must have a detailed cost sheet.

Categories:

Raw Materials
- Pork
- Chicken
- Fish
- Rice
- Vegetables
- Bamboo Shoot
- Axone
- Anishi
- Black Sesame
- Fish Powder
- Other Ingredients

Operations:
- Labour
- Cooking Gas
- Transport
- Venue
- Disposable Items
- Packaging
- Other Expenses

Each expense:

Date
Category
Description
Supplier
Quantity
Rate
Amount
Payment Mode

Automatically calculate:

Total Expenditure

Cost Per Plate

Revenue Per Plate

Gross Surplus

Surplus Per Plate

--------------------------------------------------
15. CATERING EVENT PROFITABILITY
--------------------------------------------------

Create an event summary.

Example:

AUTHENTIC NAGA FOOD
Event ANF-2026-001

ABC Association
25 September 2026
150 Plates

REVENUE
₹45,000

EXPENDITURE
₹23,700

GROSS SURPLUS
₹21,300

COST PER PLATE
₹158

REVENUE PER PLATE
₹300

SURPLUS PER PLATE
₹142

Show a simple visual revenue vs expenditure comparison.

Buttons:

View Expenses
Add Expense
Record Payment
Print Invoice
Print Event Statement
Export Excel

--------------------------------------------------
16. AUTOMATIC ACCOUNTING SYNC FOR CATERING
--------------------------------------------------

Every catering transaction must automatically sync with accounting.

Example:

Customer payment:
₹45,000

Automatically creates:

Day Book → Receipt
Sales/Revenue Register → ₹45,000
Customer Ledger → ₹45,000
Authentic Naga Food Revenue → ₹45,000

Pork purchase:
₹8,000

Automatically creates:

Day Book → Payment
Purchase Register → ₹8,000
Authentic Naga Food Expense → ₹8,000
Supplier Ledger → ₹8,000

At the event level show:

EVENT PROFITABILITY
Revenue
Expenses
Surplus

--------------------------------------------------
17. BUSINESS UNIT MANAGEMENT
--------------------------------------------------

Create a Business Unit screen.

Business Units:

Authentic Naga Food
Bastenga
Penjung Han
Machi Han
Farm Harvest
Cloud Kitchen
First Pick
Other

Every transaction should have a Business Unit.

This allows management reports such as:

Revenue by Business
Expenses by Business
Surplus by Business
Stock by Business

--------------------------------------------------
18. STOCK REGISTER
--------------------------------------------------

Create Stock Register.

Fields:

Stock ID
Item
Category
Unit
Opening Quantity
Purchases
Sales/Consumption
Adjustments
Closing Quantity
Rate
Stock Value

Categories:

Raw Materials
Finished Products
Packaging Materials
Poultry Feed
Pig Feed
Food Ingredients
Other

Buttons:

Add Purchase
Record Sale
Stock Adjustment
Stock Count

--------------------------------------------------
19. ASSET REGISTER
--------------------------------------------------

Create:

FIXED ASSET REGISTER

Columns:

Asset ID
Asset Name
Category
Purchase Date
Supplier
Purchase Cost
Funding Source
Location
Useful Life
Depreciation
Accumulated Depreciation
Net Book Value
Status

Categories:

Kitchen Equipment
Office Equipment
Computer & IT
Furniture
Vehicle
Machinery
CFC Equipment
Farm Equipment
Other

Asset detail page:

Purchase Cost
Depreciation
Current Book Value
Location
Documents
Maintenance History

When an asset is purchased, automatically update:

Day Book
Cash/Bank
Asset Register
General Ledger
Balance Sheet

--------------------------------------------------
20. INVESTMENT REGISTER
--------------------------------------------------

Create:

INVESTMENT REGISTER

Fields:

Investment ID
Date
Investment Type
Institution
Description
Amount Invested
Source Account
Interest/Return Rate
Maturity Date
Interest Received
Current Value
Status

Types:

Fixed Deposit
Bank Deposit
Shares
Cooperative Investment
Other Investment

Investment transaction automatically updates:

Bank/Cash
Investment Asset
Investment Register
General Ledger

--------------------------------------------------
21. GENERAL LEDGER
--------------------------------------------------

Create account-wise ledger.

Filters:

Account
Date
Business Unit
Financial Year

Columns:

Date
Particulars
Reference
Debit
Credit
Balance

Example accounts:

Cash
Bank
Share Capital
Loan Receivable
Loan Interest Income
Catering Revenue
Purchase
Salary
Electricity
Transport
Assets
Investments
Stock
Other Expenses

--------------------------------------------------
22. TRIAL BALANCE
--------------------------------------------------

Create:

TRIAL BALANCE

Columns:

Account Name
Debit
Credit

Bottom:

Total Debit
Total Credit

Show:

✓ Trial Balance Balanced

or

⚠ Difference Detected

--------------------------------------------------
23. INCOME & EXPENDITURE / PROFIT & LOSS
--------------------------------------------------

Create financial statement.

Income:

Catering Revenue
Product Sales
Interest Income
Other Income

Expenses:

Raw Materials
Salary
Labour
Electricity
Transport
Printing
Meeting Expenses
Office Expenses
Depreciation
Other Expenses

Show:

Total Income
Total Expenditure
Surplus / Deficit

Allow filtering by:

Financial Year
Business Unit

--------------------------------------------------
24. BALANCE SHEET
--------------------------------------------------

Create professional accounting statement.

LIABILITIES

Share Capital
Reserves
Surplus/Deficit
Loans/Payables
Other Liabilities

ASSETS

Cash
Bank
Investments
Loans Receivable
Stock
Fixed Assets
Other Assets

Show:

TOTAL ASSETS
TOTAL LIABILITIES

The system should visually indicate if the balance sheet balances.

--------------------------------------------------
25. REPORT CENTER
--------------------------------------------------

Create a central Report Center.

Cards:

Daily Cash Book
Bank Book
BRS
Loan Register
Loan Repayment
Share Ledger
Membership Register
Stock Register
Asset Register
Investment Register
General Ledger
Trial Balance
Income & Expenditure
Balance Sheet
Catering Event Report
Business Performance Report

Buttons:

View
Print
Export PDF
Export Excel

--------------------------------------------------
26. AUDIT TRAIL
--------------------------------------------------

Create an Audit Trail.

Columns:

Date/Time
User
Action
Transaction ID
Old Value
New Value
Reason

Actions:

Created
Edited
Reversed
Approved
Cancelled

Accounting transactions should not be permanently deleted.

Use:

REVERSE TRANSACTION

rather than delete.

--------------------------------------------------
27. USER ROLES
--------------------------------------------------

Create:

Administrator
Secretary
Treasurer
Accountant
Data Entry Operator
Auditor
Viewer

Permissions:

View
Create
Edit
Approve
Reverse
Export
Reports

Auditor should have read-only access.

--------------------------------------------------
28. MOBILE DESIGN
--------------------------------------------------

Create mobile-responsive screens.

Bottom navigation:

Home
Transactions
Business
Registers
More

Floating action button:

+

Quick actions:

Receive
Pay
Catering
Loan
Purchase
Sale

Tables should become card-based on mobile.

--------------------------------------------------
29. IMPORTANT USER EXPERIENCE
--------------------------------------------------

The user should never feel that they are entering the same information multiple times.

Whenever a transaction is created, show:

"ACCOUNTING SYNC"

✓ Day Book
✓ Cash/Bank
✓ Relevant Register
✓ General Ledger
✓ Business Unit
✓ Financial Statements

Use a green confirmation banner:

"Transaction recorded and registers synchronized."

--------------------------------------------------
30. DEMO DATA
--------------------------------------------------

Use realistic sample data for prototype demonstration.

Use:

Organization:
Tribal Harvest Marketing Cooperative Society Ltd.

Business:
Authentic Naga Food

Example customer:
ABC Association

Example catering event:

Date:
25 September 2026

Plates:
150

Price:
₹300

Revenue:
₹45,000

Expenses:
₹23,700

Surplus:
₹21,300

Also create sample:

Member loan:
₹10,000

Interest:
10% p.a.

Share contribution:
₹2,000

Asset:
Deep Freezer
₹45,000

Investment:
₹1,00,000

Use Indian Rupee formatting throughout.

--------------------------------------------------
31. PROTOTYPE FLOW
--------------------------------------------------

Make the prototype clickable.

FLOW 1:

Login
→ Dashboard
→ New Transaction
→ Receive Money
→ Save
→ Accounting Sync
→ Day Book

FLOW 2:

Dashboard
→ Authentic Naga Food
→ New Catering Event
→ Enter Customer
→ Enter Plates
→ Enter Price
→ Add Expenses
→ Event Summary
→ Profitability
→ Accounting Sync

FLOW 3:

Dashboard
→ Loan Management
→ Select Member
→ Disburse Loan
→ Confirmation
→ Loan Register
→ Member Ledger
→ Day Book

FLOW 4:

Dashboard
→ Members
→ Member Profile
→ Shares
→ Loan
→ Transactions
→ Statement

FLOW 5:

Dashboard
→ Reports
→ Trial Balance
→ Income & Expenditure
→ Balance Sheet

--------------------------------------------------
32. DESIGN REQUIREMENT
--------------------------------------------------

Create a polished high-fidelity prototype.

Do not create only static mockups.

Make buttons, navigation, forms, tables, filters, modals and important flows clickable.

Use consistent components:

Buttons
Cards
Tables
Forms
Badges
Tabs
Modals
Dropdowns
Date pickers
Search
Filters
Status indicators
Confirmation messages

Create reusable components and consistent spacing.

The prototype should look like a real application ready for development.

Prioritize clarity and usability over decoration.

The physical cooperative registers provided as references should influence the structure of the digital registers, especially:

Daily Cash Book
Loan Register
Loan Repayment Register
Share Ledger
Stock Register

The final product should feel like:

"Traditional Cooperative Registers + Modern Digital Accounting + Business Management"

under one Tribal Harvest system.